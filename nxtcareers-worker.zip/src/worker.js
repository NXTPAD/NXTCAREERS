// NXT Careers — Cloudflare Worker entry.
// /api/* is handled here; everything else is served from ./public (static assets).
import * as jobs from './api/jobs.js';
import * as ai from './api/ai.js';
import * as verify from './api/verify.js';
import * as health from './api/health.js';

const ROUTES = {
  '/api/jobs': jobs,
  '/api/ai': ai,
  '/api/verify': verify,
  '/api/health': health
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname.startsWith('/api/')) {
      const mod = ROUTES[url.pathname.replace(/\/$/, '')];
      if (!mod) return json({ error: 'not_found' }, 404);
      const handler = request.method === 'GET' ? mod.onRequestGet
                    : request.method === 'POST' ? mod.onRequestPost : null;
      if (!handler) return json({ error: 'method_not_allowed' }, 405);
      try {
        return await handler({ request, env, waitUntil: p => ctx.waitUntil(p) });
      } catch (e) {
        return json({ error: 'server_error' }, 500);
      }
    }

    // Static site (landing page at /, app at /app/)
    return env.ASSETS.fetch(request);
  }
};

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });
}

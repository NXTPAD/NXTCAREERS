// GET /api/verify?session_id=cs_...
// Confirms a Stripe Checkout session (created by your Payment Links) was paid and returns the plan.
// Secrets required: STRIPE_SECRET_KEY. Optional: STRIPE_PRO_PRICE, STRIPE_PASS_PRICE (price IDs) —
// if not set, the plan is inferred from the session mode (subscription = Pro, one-time = Pass).
export async function onRequestGet({ request, env }) {
  const sid = new URL(request.url).searchParams.get('session_id') || '';
  if (!/^cs_[A-Za-z0-9_]+$/.test(sid)) return json({ ok: false, error: 'Invalid session ID' }, 400);
  if (!env.STRIPE_SECRET_KEY) return json({ ok: false, error: 'Payments are not configured yet' }, 503);

  const r = await fetch(`https://api.stripe.com/v1/checkout/sessions/${sid}?expand[]=line_items&expand[]=subscription`, {
    headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}` }
  });
  if (!r.ok) return json({ ok: false, error: 'Payment not found' }, 404);
  const s = await r.json();
  if (s.payment_status !== 'paid' && s.status !== 'complete') return json({ ok: false, error: 'Payment not completed' }, 402);

  const price = s.line_items?.data?.[0]?.price?.id;
  let plan = s.mode === 'subscription' ? 'pro' : 'pass';
  if (env.STRIPE_PRO_PRICE && price === env.STRIPE_PRO_PRICE) plan = 'pro';
  if (env.STRIPE_PASS_PRICE && price === env.STRIPE_PASS_PRICE) plan = 'pass';

  let until;
  if (plan === 'pro' && s.subscription?.current_period_end) {
    if (!['active', 'trialing', 'past_due'].includes(s.subscription.status)) return json({ ok: false, error: 'Subscription is not active' }, 402);
    until = new Date(s.subscription.current_period_end * 1000).toISOString().slice(0, 10);
  } else {
    const d = new Date(s.created * 1000); d.setDate(d.getDate() + (plan === 'pass' ? 90 : 31));
    until = d.toISOString().slice(0, 10);
  }
  return json({ ok: true, plan, until, email: s.customer_details?.email || null });
}
function json(obj, status = 200) { return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } }); }

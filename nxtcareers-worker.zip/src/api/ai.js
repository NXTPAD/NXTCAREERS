// POST /api/ai  { task: "bullet"|"summary"|"cover"|"interview", payload: {...} }
// AI writing via the Claude API. Secret required: ANTHROPIC_API_KEY. Optional: AI_MODEL.
// If the key is missing, returns 503 and the app falls back to its built-in writer.
const MODEL_DEFAULT = 'claude-sonnet-5';
const SYSTEM = `You are NXT Careers, an expert resume writer and career coach. Write in clear, confident, plain English.
Never invent employers, degrees, dates or numbers the user did not provide. When a metric would help but is unknown, use a bracketed placeholder like [N]% so the user fills it in. Return only what is asked for, no preamble.`;

export async function onRequestPost({ request, env }) {
  if (!env.ANTHROPIC_API_KEY) return json({ error: 'ai_not_configured' }, 503);
  let body; try { body = await request.json(); } catch { return json({ error: 'bad_json' }, 400); }
  const { task, payload = {} } = body || {};
  const r = payload.resume ? slimResume(payload.resume) : null;
  let prompt, max = 700, parseJSON = false;

  switch (task) {
    case 'bullet':
      prompt = `Rewrite this resume bullet for a ${clip(payload.title, 80) || 'professional'} so it starts with a strong action verb, is specific, and shows impact. One sentence, under 30 words.\n\nBullet: ${clip(payload.text, 400)}`;
      max = 120; break;
    case 'summary':
      prompt = `Write a 2–3 sentence professional resume summary (40–70 words, first person implied, no "I") from this resume:\n${JSON.stringify(r)}`;
      max = 220; break;
    case 'cover':
      prompt = `Write a ${clip(payload.tone, 20) || 'professional'} cover letter (250–330 words; ~180 if tone is "concise") for this job using only facts from the resume. Start with "Dear ${clip(payload.job?.company, 80)} Hiring Team," and end with "Best regards," then the candidate's name, email and phone on separate lines.\n\nJOB:\n${JSON.stringify(payload.job).slice(0, 4000)}\n\nRESUME:\n${JSON.stringify(r)}`;
      max = 900; break;
    case 'interview':
      prompt = `Create 9 likely interview questions for this job, tailored to the candidate. Mix: 1 Opener, 2 Role, 2 Technical, 1 Gap (a requirement the resume lacks), 2 Behavioral, 1 Company. For each give a concise "how to answer" plan (2–3 sentences) that points to a specific item from the candidate's resume when possible.
Return ONLY JSON: [{"cat":"Opener","q":"...","a":"..."}]\n\nJOB:\n${JSON.stringify(payload.job).slice(0, 4000)}\n\nRESUME:\n${JSON.stringify(r)}`;
      max = 1800; parseJSON = true; break;
    default:
      return json({ error: 'unknown_task' }, 400);
  }

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: env.AI_MODEL || MODEL_DEFAULT, max_tokens: max, system: SYSTEM, messages: [{ role: 'user', content: prompt }] })
  });
  if (!res.ok) return json({ error: 'ai_upstream_' + res.status }, 502);
  const data = await res.json();
  const text = (data.content || []).filter(c => c.type === 'text').map(c => c.text).join('').trim();

  if (parseJSON) {
    try { const m = text.match(/\[[\s\S]*\]/); return json({ items: JSON.parse(m[0]) }); }
    catch { return json({ error: 'ai_parse' }, 502); }
  }
  return json({ text: text.replace(/^["']|["']$/g, '') });
}

function slimResume(r) {
  return {
    contact: { name: r.contact?.name, title: r.contact?.title, email: r.contact?.email, phone: r.contact?.phone, location: r.contact?.location },
    summary: clip(r.summary, 800),
    experience: (r.experience || []).slice(0, 6).map(e => ({ role: e.role, company: e.company, start: e.start, end: e.end, bullets: (e.bullets || []).slice(0, 6).map(b => clip(b, 300)) })),
    education: (r.education || []).slice(0, 3).map(e => ({ school: e.school, degree: e.degree, end: e.end })),
    skills: (r.skills || []).slice(0, 40),
    projects: (r.projects || []).slice(0, 4).map(p => ({ name: p.name, detail: clip(p.detail, 300) }))
  };
}
const clip = (s, n) => String(s || '').slice(0, n);
function json(obj, status = 200) { return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } }); }

// GET /api/jobs?query=react+developer&location=Dallas,+TX&remote=1
// Live job listings from JSearch (RapidAPI), which aggregates Google for Jobs: Indeed, LinkedIn,
// Glassdoor, ZipRecruiter and more. Secret required: RAPIDAPI_KEY.
// Uses JSearch's current /search-v2 endpoint (falls back to the older /search if needed).
// Responses are cached at the edge for 1 hour to save API quota.
const COLORS = ['#2b86f0','#14b8a6','#6366f1','#22c55e','#a855f7','#f59e0b','#ef4444','#06b6d4','#ec4899','#f97316'];
const HOST = 'jsearch.p.rapidapi.com';

export async function onRequestGet({ request, env, waitUntil }) {
  const url = new URL(request.url);
  const query = (url.searchParams.get('query') || 'jobs').slice(0, 120);
  const location = (url.searchParams.get('location') || '').slice(0, 80);
  const remote = url.searchParams.get('remote') === '1' || /remote/i.test(location);
  const cursor = (url.searchParams.get('cursor') || '').slice(0, 500);

  const key = (env.RAPIDAPI_KEY || '').trim();
  if (!key) return json({ source: 'none', jobs: [] });

  const cache = typeof caches !== 'undefined' ? caches.default : null;
  const cacheKey = new Request(`https://cache.nxtcareers/jobs-v2?q=${encodeURIComponent(query)}&l=${encodeURIComponent(location)}&r=${remote}&c=${encodeURIComponent(cursor)}`);
  if (cache) { const hit = await cache.match(cacheKey); if (hit) return hit; }

  // Natural-language query works best with JSearch: "warehouse jobs in Fort Smith, AR"
  let q = /\bjobs?\b/i.test(query) ? query : `${query} jobs`;
  if (location && !/remote/i.test(location)) q += ` in ${location}`;
  if (remote) q = `remote ${q}`;

  const headers = { 'X-RapidAPI-Key': key, 'X-RapidAPI-Host': HOST };
  try {
    // 1) current endpoint
    const v2 = new URL(`https://${HOST}/search-v2`);
    v2.searchParams.set('query', q);
    if (cursor) v2.searchParams.set('cursor', cursor);
    let r = await fetch(v2, { headers });

    // 2) older endpoint, only if v2 isn't available on this plan/account
    if (r.status === 404) {
      const v1 = new URL(`https://${HOST}/search`);
      v1.searchParams.set('query', q);
      v1.searchParams.set('page', '1');
      v1.searchParams.set('num_pages', '1');
      r = await fetch(v1, { headers });
    }

    if (!r.ok) {
      let detail = '';
      try { detail = (await r.text()).slice(0, 300); } catch {}
      return json({ source: 'error', status: r.status, detail, jobs: [] });
    }

    const body = await r.json();
    const list = findJobs(body);
    if (!list) {
      // Unknown shape: report its structure (not its content) so it can be adapted quickly.
      const shape = describe(body);
      return json({ source: 'error', status: 200, detail: 'Unrecognized response shape: ' + shape, jobs: [] });
    }
    const next = body.cursor || body.next_cursor || body.data?.cursor || body.data?.next_cursor || null;
    const res = json({ source: 'live', jobs: list.map(normalize).filter(j => j.title), cursor: next }, 200, { 'Cache-Control': 'public, max-age=3600' });
    if (cache) waitUntil(cache.put(cacheKey, res.clone()));
    return res;
  } catch (e) {
    return json({ source: 'error', detail: String(e && e.message || e).slice(0, 200), jobs: [] });
  }
}

function findJobs(b) {
  if (!b || typeof b !== 'object') return null;
  if (Array.isArray(b.data)) return b.data;
  if (Array.isArray(b.jobs)) return b.jobs;
  if (b.data && Array.isArray(b.data.jobs)) return b.data.jobs;
  if (b.data && Array.isArray(b.data.data)) return b.data.data;
  if (Array.isArray(b.results)) return b.results;
  if (Array.isArray(b)) return b;
  return null;
}
function describe(b) {
  if (!b || typeof b !== 'object') return typeof b;
  return Object.keys(b).slice(0, 12).map(k => {
    const v = b[k];
    const t = Array.isArray(v) ? 'array' : v === null ? 'null' : typeof v;
    return t === 'object' ? `${k}{${Object.keys(v).slice(0, 8).join(',')}}` : `${k}:${t}`;
  }).join(' ');
}

function normalize(j, i) {
  const id = j.job_id || j.id || `${j.job_title || ''}-${j.employer_name || ''}-${i}`;
  const city = j.job_city, state = j.job_state;
  const isRemote = !!(j.job_is_remote ?? j.is_remote ?? j.work_from_home);
  const loc = (city || state) ? [city, state].filter(Boolean).join(', ')
            : (j.job_location || j.location || (isRemote ? 'Remote' : j.job_country || ''));
  const h = j.job_highlights || {};
  const rawType = j.job_employment_type || (Array.isArray(j.job_employment_types) ? j.job_employment_types[0] : '') || '';
  const type = { FULLTIME: 'Full-time', PARTTIME: 'Part-time', CONTRACTOR: 'Contract', INTERN: 'Internship',
                 'Full-time': 'Full-time', 'Part-time': 'Part-time', 'Contractor': 'Contract', 'Internship': 'Internship' }[rawType] || (rawType || 'Full-time');
  const desc = String(j.job_description || j.description || '').replace(/\s+/g, ' ').trim();
  const apply = j.job_apply_link || (Array.isArray(j.apply_options) && j.apply_options[0]?.apply_link) || j.job_google_link || '';
  const employer = j.employer_name || j.company_name || 'Company';
  return {
    id: 'js_' + id,
    title: j.job_title || j.title || '',
    company: employer,
    logo: j.employer_logo || '',
    color: COLORS[employer.length % COLORS.length],
    location: loc,
    remote: isRemote,
    type,
    salary: salary(j),
    posted: j.job_posted_at_datetime_utc || (j.job_posted_at_timestamp ? new Date(j.job_posted_at_timestamp * 1000).toISOString() : new Date().toISOString()),
    publisher: j.job_publisher || '',
    apply,
    desc: desc.length > 900 ? desc.slice(0, 900) + '…' : desc,
    resp: (h.Responsibilities || []).slice(0, 8),
    qual: (h.Qualifications || []).slice(0, 8),
    benefits: (h.Benefits || []).slice(0, 6)
  };
}
function salary(j) {
  if (j.job_salary_string) return String(j.job_salary_string).slice(0, 40);
  if (typeof j.job_salary === 'string' && j.job_salary) return j.job_salary.slice(0, 40);
  const a = j.job_min_salary, b = j.job_max_salary, p = j.job_salary_period;
  if (!a && !b) return '';
  const f = n => p === 'HOUR' ? '$' + Math.round(n) : '$' + Math.round(n / 1000) + 'k';
  const s = a && b ? `${f(a)} – ${f(b)}` : f(a || b);
  return p === 'HOUR' ? s + ' / hr' : s;
}
function json(obj, status = 200, headers = {}) {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json', ...headers } });
}

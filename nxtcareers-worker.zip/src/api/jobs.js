// GET /api/jobs?query=react+developer&location=Dallas,+TX&remote=1&page=1
// Live job listings from JSearch (RapidAPI), which aggregates Google for Jobs: Indeed, LinkedIn,
// Glassdoor, ZipRecruiter and more. Secret required: RAPIDAPI_KEY.
// Responses are cached at the edge for 1 hour to save API quota.
const COLORS = ['#2b86f0','#14b8a6','#6366f1','#22c55e','#a855f7','#f59e0b','#ef4444','#06b6d4','#ec4899','#f97316'];

export async function onRequestGet({ request, env, waitUntil }) {
  const url = new URL(request.url);
  const query = (url.searchParams.get('query') || 'jobs').slice(0, 120);
  const location = (url.searchParams.get('location') || '').slice(0, 80);
  const remote = url.searchParams.get('remote') === '1';
  const page = Math.max(1, Math.min(5, parseInt(url.searchParams.get('page') || '1')));

  const key = (env.RAPIDAPI_KEY || '').trim();
  if (!key) return json({ source: 'none', jobs: [] });

  const cache = caches.default;
  const cacheKey = new Request(`https://cache.nxtcareers/jobs?q=${encodeURIComponent(query)}&l=${encodeURIComponent(location)}&r=${remote}&p=${page}`);
  const hit = await cache.match(cacheKey);
  if (hit) return hit;

  const q = location && !/remote/i.test(location) ? `${query} in ${location}` : query;
  const api = new URL('https://jsearch.p.rapidapi.com/search');
  api.searchParams.set('query', q);
  api.searchParams.set('page', String(page));
  api.searchParams.set('num_pages', '1');
  api.searchParams.set('date_posted', 'month');
  if (remote || /remote/i.test(location)) api.searchParams.set('remote_jobs_only', 'true');

  try {
    const r = await fetch(api, { headers: { 'X-RapidAPI-Key': key, 'X-RapidAPI-Host': 'jsearch.p.rapidapi.com' } });
    if (!r.ok) {
      // Report JSearch's reason (never the key) so problems are easy to diagnose.
      let detail = '';
      try { detail = (await r.text()).slice(0, 300); } catch {}
      return json({ source: 'error', status: r.status, detail, jobs: [] });
    }
    const data = await r.json();
    const jobs = (data.data || []).map(normalize);
    const res = json({ source: 'live', jobs }, 200, { 'Cache-Control': 'public, max-age=3600' });
    waitUntil(cache.put(cacheKey, res.clone()));
    return res;
  } catch (e) {
    return json({ source: 'error', detail: String(e && e.message || e).slice(0, 200), jobs: [] });
  }
}

function normalize(j, i) {
  const loc = j.job_is_remote && !j.job_city ? 'Remote' : [j.job_city, j.job_state].filter(Boolean).join(', ') || j.job_country || '';
  const h = j.job_highlights || {};
  const type = { FULLTIME: 'Full-time', PARTTIME: 'Part-time', CONTRACTOR: 'Contract', INTERN: 'Internship' }[j.job_employment_type] || (j.job_employment_type || 'Full-time');
  const desc = (j.job_description || '').replace(/\s+/g, ' ').trim();
  return {
    id: 'js_' + j.job_id,
    title: j.job_title,
    company: j.employer_name || 'Company',
    logo: j.employer_logo || '',
    color: COLORS[(j.employer_name || '').length % COLORS.length],
    location: loc,
    remote: !!j.job_is_remote,
    type,
    salary: salary(j),
    posted: j.job_posted_at_datetime_utc || new Date().toISOString(),
    publisher: j.job_publisher || '',
    apply: j.job_apply_link || j.job_google_link || '',
    desc: desc.length > 900 ? desc.slice(0, 900) + '…' : desc,
    resp: (h.Responsibilities || []).slice(0, 8),
    qual: (h.Qualifications || []).slice(0, 8),
    benefits: (h.Benefits || []).slice(0, 6)
  };
}
function salary(j) {
  const a = j.job_min_salary, b = j.job_max_salary, p = j.job_salary_period;
  if (!a && !b) return '';
  const f = n => p === 'HOUR' ? '$' + Math.round(n) : '$' + Math.round(n / 1000) + 'k';
  const s = a && b ? `${f(a)} – ${f(b)}` : f(a || b);
  return p === 'HOUR' ? s + ' / hr' : s;
}
function json(obj, status = 200, headers = {}) {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json', ...headers } });
}

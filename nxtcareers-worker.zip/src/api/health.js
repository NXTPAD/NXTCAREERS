// GET /api/health — tells the app which services are configured (never exposes the keys).
export async function onRequestGet({ env }) {
  return new Response(JSON.stringify({
    ok: true,
    version: 'jobs-autodetect-3',
    jobs: !!env.RAPIDAPI_KEY,
    ai: !!env.ANTHROPIC_API_KEY,
    stripe: !!env.STRIPE_SECRET_KEY
  }), { headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
}

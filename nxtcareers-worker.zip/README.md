# NXT Careers

AI resume builder, live job search, and application tracker. Part of the NXT Cloud Business Suite.

- `/` : landing page (features, pricing, FAQ)
- `/app/` : the app (dashboard, job search, resume builder, tracker, cover letters, interview prep, billing, settings). It's an installable PWA for iOS and Android via "Add to Home Screen".

## Project layout (Cloudflare Worker)

```
wrangler.jsonc    Worker config (name "nxtcareers", serves ./public, runs the Worker for /api/*)
package.json
src/worker.js     routes /api/* to the handlers below; everything else = static site
src/api/          jobs.js (JSearch), ai.js (Claude), verify.js (Stripe), health.js
public/           landing page (index.html), the app (/app), assets, config.js, PWA files
```

## Deploy (GitHub + Cloudflare Workers)

1. Upload the **contents** of this folder to a GitHub repo (wrangler.jsonc must be at the top level).
2. In Cloudflare, go to **Workers & Pages → Create → Import a repository** and pick the repo.
   - Deploy command: `npx wrangler deploy` (the default)
   - Leave the build command empty.
3. After the first deploy, open the Worker's **Settings → Variables and Secrets** and add these secrets (type **Secret**):

| Secret | What it turns on | Where to get it |
|---|---|---|
| `RAPIDAPI_KEY` | Live jobs from Indeed, LinkedIn, Glassdoor, ZipRecruiter and more (JSearch) | rapidapi.com: subscribe to the **JSearch** API |
| `ANTHROPIC_API_KEY` | Full AI writing (bullets, summaries, cover letters, interview questions) | console.anthropic.com |
| `STRIPE_SECRET_KEY` | Verifies payments and unlocks Pro or the Pass | dashboard.stripe.com → Developers → API keys |
| `AI_MODEL` *(optional)* | Overrides the Claude model (default `claude-sonnet-5`) | |
| `STRIPE_PRO_PRICE`, `STRIPE_PASS_PRICE` *(optional)* | Exact price-ID matching | Stripe price IDs |

Each service works without its key (redeploy isn't needed; secrets apply right away): the app falls back to sample job listings and a built-in writer, so nothing breaks before you add the keys. **Settings → Connections** inside the app shows what's live.

## Payments (Stripe Payment Links)

1. In Stripe, create two Payment Links:
   - **Pro**: $9.99 per month (recurring)
   - **Job Hunt Pass**: $24.99 (one-time)
2. On each link, go to *After payment → Don't show confirmation page → Redirect* and set it to:
   `https://YOUR-DOMAIN/app/#/billing?session_id={CHECKOUT_SESSION_ID}`
3. Paste both link URLs into `config.js`, and set `demoMode: false` before launch. While demo mode is on, the Upgrade buttons unlock plans for free, which is useful for testing.

## Plans (paid only)

Anyone can sign up and look around: the dashboard, job search and the resume editor. Everything else needs Pro or the Job Hunt Pass:

| Locked until they pay | Pro $9.99/mo | Job Hunt Pass $24.99 / 3 mo |
|---|---|---|
| AI writing, cover letters, interview prep | Unlimited | Unlimited |
| Apply + application tracking | Unlimited | Unlimited |
| PDF download, Bold/Classic templates | Yes | Yes |

## Notes
- User data (resume, applications, letters) is stored in the browser (localStorage). Users can export and import a backup from Settings. Syncing across devices would need accounts plus a database (Cloudflare D1), which is the natural next step.
- The plan unlock is stored per device. A user who paid on another device can restore it by pasting their Stripe checkout session ID on the Billing page.
- Sample job companies are fictional. They only appear until `RAPIDAPI_KEY` is set.

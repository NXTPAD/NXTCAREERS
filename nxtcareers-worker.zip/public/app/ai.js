/* NXT Careers — AI + scoring engine.
 * Calls /api/ai (Cloudflare Pages Function → Claude) when available and falls back to
 * a built-in writer so every feature keeps working offline or before keys are set. */
(function(){
const {SKILLS} = window.NXTC_DATA;

const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const SKILL_RX = SKILLS.map(s=>[s,new RegExp('(^|[^a-z0-9+#])'+esc(s)+'(?![a-z0-9+#])','i')]);
const PRETTY = {"javascript":"JavaScript","typescript":"TypeScript","react":"React","next.js":"Next.js","node.js":"Node.js","node":"Node.js","graphql":"GraphQL","sql":"SQL","postgresql":"PostgreSQL","mysql":"MySQL","mongodb":"MongoDB","aws":"AWS","gcp":"GCP","ci/cd":"CI/CD","html":"HTML","css":"CSS","ux":"UX","ui":"UI","api":"APIs","apis":"APIs","rest":"REST APIs","a/b testing":"A/B testing","seo":"SEO","sem":"SEM","crm":"CRM","b2b":"B2B","saas":"SaaS","osha":"OSHA","osha 30":"OSHA 30","nec":"NEC","plc":"PLC","hvac":"HVAC","epic":"Epic","ehr":"EHR","bls":"BLS","acls":"ACLS","etl":"ETL","dbt":"dbt","jira":"Jira","figma":"Figma","tableau":"Tableau","power bi":"Power BI","excel":"Excel","python":"Python","java":"Java","go":"Go","rust":"Rust","docker":"Docker","kubernetes":"Kubernetes","terraform":"Terraform","salesforce":"Salesforce","hubspot":"HubSpot","procore":"Procore","autocad":"AutoCAD","jest":"Jest","cypress":"Cypress","playwright":"Playwright","vue":"Vue","angular":"Angular","tailwind":"Tailwind","redux":"Redux","linux":"Linux","react native":"React Native","swift":"Swift","kotlin":"Kotlin","pandas":"pandas","numpy":"NumPy","google ads":"Google Ads","lean":"Lean","six sigma":"Six Sigma","vite":"Vite","webpack":"Webpack","looker":"Looker","airflow":"Airflow","spark":"Spark"};
const pretty = s => PRETTY[s] || s.replace(/\b\w/g,c=>c.toUpperCase());
const canon = s => (s==='node'?'node.js':(s==='apis'||s==='rest')?'api':s==='python pandas'?'pandas':s);

function keywords(text){
  const out = new Set();
  for(const [s,rx] of SKILL_RX) if(rx.test(text)) out.add(canon(s));
  // collapse overlaps ("osha" within "osha 30")
  if(out.has('osha 30')) out.delete('osha');
  if(out.has('communication skills')) out.delete('communication');
  return [...out];
}
function jobText(j){return [j.title,j.desc,...(j.resp||[]),...(j.qual||[])].join(' \n ')}
function resumeText(r){
  return [r.contact.title,r.summary,...r.skills,...r.experience.flatMap(e=>[e.role,e.company,...e.bullets]),...r.projects.map(p=>p.name+' '+p.detail),...r.education.map(e=>e.degree+' '+e.detail)].join(' \n ');
}
function match(job,resume){
  const jk = keywords(jobText(job)), rk = new Set(keywords(resumeText(resume)));
  const have = jk.filter(k=>rk.has(k)), missing = jk.filter(k=>!rk.has(k));
  let score = jk.length ? Math.round(35 + 65*have.length/jk.length) : 50;
  const t = (resume.contact.title||'').toLowerCase(), jt = job.title.toLowerCase();
  if(t && jt.split(/\W+/).some(w=>w.length>3 && t.includes(w))) score += 6;
  return {score:Math.min(98,score),have:have.map(pretty),missing:missing.map(pretty),haveRaw:have,missingRaw:missing};
}

const VERBS = /^(led|built|shipped|launched|designed|developed|created|delivered|drove|grew|increased|reduced|cut|improved|managed|owned|automated|implemented|migrated|architected|mentored|resolved|streamlined|negotiated|closed|installed|coordinated|trained|analyzed|optimized|scaled|spearheaded|established|introduced|integrated|achieved|generated|won|saved|oversaw|directed|produced|maintained|supported|assisted|handled|performed|provided|wrote|ran|organized|diagnosed|repaired|administered|documented)\b/i;
function improveBullet(b){
  let s = b.trim().replace(/\.$/,'');
  s = s.replace(/^(i\s+)?(was\s+)?(responsible for|in charge of|tasked with|duties included|worked on|helped (with|to)|assisted (with|in)|involved in)\s+/i,'');
  let conv=false;
  s = s.replace(/^(\w+?)ing\b/i,(m,w)=>{
    const irr={build:'Built',lead:'Led',writ:'Wrote',run:'Ran',mak:'Made',do:'Did',set:'Set',teach:'Taught',sell:'Sold',driv:'Drove',giv:'Gave',tak:'Took',keep:'Kept',find:'Found',hold:'Held',bring:'Brought',meet:'Met',fix:'Fixed',get:'Got',win:'Won'};
    const k=w.toLowerCase(), base=k.replace(/([bdgmnprt])\1$/,'$1'); conv=true;
    if(irr[base]) return irr[base];
    const past = /e$/.test(k)?k+'d':/[^aeiou]y$/.test(k)?k.slice(0,-1)+'ied':k+'ed';
    return past.charAt(0).toUpperCase()+past.slice(1);
  });
  if(!conv && !VERBS.test(s) && !/^[a-z]+ed\b/i.test(s)){
    const l = s.toLowerCase(); let v='Delivered';
    if(/access|wcag|a11y/.test(l)) v='Resolved'; else if(/bug|fix|issue|error/.test(l)) v='Resolved';
    else if(/site|app|feature|page|component|tool/.test(l)) v='Built'; else if(/test/.test(l)) v='Automated testing for';
    else if(/customer|client|patient/.test(l)) v='Supported'; else if(/team|staff|crew/.test(l)) v='Led';
    else if(/report|data|dashboard/.test(l)) v='Analyzed'; else if(/sale|deal|account/.test(l)) v='Closed';
    s = v+' '+s.charAt(0).toLowerCase()+s.slice(1);
  }
  s = s.charAt(0).toUpperCase()+s.slice(1);
  s = s.replace(/^(Resolved|Fixed) accessibility fixes/i,'Resolved accessibility issues');
  if(!/\d/.test(s)){
    const l=s.toLowerCase();
    if(/access/.test(l)) s+=' across [N] client sites, bringing pages to WCAG 2.1 AA';
    else if(/dashboard|report|data|analy/.test(l)) s+=', used by [N] stakeholders to make weekly decisions';
    else if(/customer|client|patient|call/.test(l)) s+=', keeping satisfaction at [N]%';
    else if(/sale|pipeline|revenue|deal/.test(l)) s+=', generating $[N] in new revenue';
    else if(/process|workflow|schedul/.test(l)) s+=', cutting turnaround time by [N]%';
    else if(/blog|content|post|newsletter|social/.test(l)) s+=', growing monthly readership by [N]%';
    else s+=', improving [metric] by [N]%';
  }
  return s;
}
function years(r){
  const ys = r.experience.map(e=>parseInt((e.start||'').match(/\d{4}/)?.[0])).filter(Boolean);
  return ys.length ? Math.max(1,new Date().getFullYear()-Math.min(...ys)) : 0;
}
const lc = s => s ? s.charAt(0).toLowerCase()+s.slice(1) : s;
const trim = s => (s||'').replace(/\.$/,'');

function localSummary(r){
  const y = years(r), sk = r.skills.slice(0,4);
  const top = r.experience[0]?.bullets?.[0];
  let s = `${r.contact.title||'Professional'} with ${y?y+'+ years':'hands-on experience'} ${sk.length?'in '+listJoin(sk):'delivering results'}.`;
  if(top) s += ` Recently ${lc(trim(top))}.`;
  s += ` Known for clear communication, owning work end to end, and raising the bar for the teams I join.`;
  return s;
}
function listJoin(a){return a.length<=1?a.join(''):a.slice(0,-1).join(', ')+' and '+a[a.length-1]}

function localCover(job,r,tone){
  const m = match(job,r), c=r.contact, y=years(r), ex=r.experience[0], ex2=r.experience[1];
  const skills = m.have.slice(0,3).length ? m.have.slice(0,3) : r.skills.slice(0,3);
  const open = tone==='enthusiastic' ? `I was genuinely excited to see the ${job.title} opening at ${job.company}` : `I'm writing to apply for the ${job.title} position at ${job.company}`;
  const p1 = `${open}. As a ${c.title||'professional'} with ${y?y+' years of':'solid'} experience in ${listJoin(skills)}, I focus on work that shows up in results, not just output.`;
  const b1 = ex?.bullets?.[0], b2 = ex?.bullets?.[1] || ex2?.bullets?.[0];
  let p2 = ex ? `In my current role at ${ex.company}, I ${lc(trim(b1||'deliver high-quality work across the team'))}.` : '';
  if(b2) p2 += ` I also ${lc(trim(b2))}.`;
  if(job.resp?.length) p2 += ` That experience lines up closely with what you need: ${lc(trim(job.resp[0]))}${job.resp[1]?' and '+lc(trim(job.resp[1])):''}.`;
  const p3 = `What draws me to ${job.company} is the work itself: ${trim(job.desc.split('. ')[0])}. I'd bring ${listJoin(m.have.slice(0,5).length?m.have.slice(0,5):r.skills.slice(0,4))} from day one${m.missing[0]?`, and I'm ready to ramp up quickly on ${m.missing[0]}`:''}.`;
  const close = tone==='concise' ? `I'd welcome a quick conversation about the role.` : `Thank you for your time and consideration. I'd welcome the chance to talk about how I can help ${job.company} hit its next milestones.`;
  const parts = [`Dear ${job.company} Hiring Team,`, p1, p2, tone==='concise'?null:p3, close, `Best regards,\n${c.name||'Your Name'}\n${[c.email,c.phone].filter(Boolean).join(' · ')}`].filter(Boolean);
  return parts.join('\n\n');
}

function localInterview(job,r){
  const m = match(job,r), qs=[];
  const bestBullet = kw => { const all=r.experience.flatMap(e=>e.bullets.map(b=>({b,e}))); const hit=all.find(x=>x.b.toLowerCase().includes(kw.toLowerCase())); return hit||all[0]; };
  qs.push({cat:'Opener',q:`Walk me through your background and why you're interested in this ${job.title} role.`,a:`Keep it to 90 seconds: present (${r.contact.title||'your role'}), past (${r.experience.map(e=>e.company).slice(0,2).join(', ')||'key experience'}), future (why ${job.company}). End by tying your strongest skill — ${m.have[0]||r.skills[0]||'your top skill'} — to their needs.`});
  (job.resp||[]).slice(0,2).forEach(x=>{const bb=bestBullet(keywords(x)[0]||x.split(' ')[1]||'');qs.push({cat:'Role',q:`Tell me about a time you had to ${lc(trim(x))}.`,a:`Use STAR. A strong story from your resume: "${bb?bb.b:'pick a recent project'}"${bb?` (${bb.e.company})`:''}. Spend most of the time on the Action, and close with the measurable Result.`})});
  m.have.slice(0,2).forEach(s=>qs.push({cat:'Technical',q:`How have you used ${s} in a real project? What would you do differently now?`,a:`Name the project, the scale (users, data, team size), a tradeoff you made with ${s}, and one lesson learned. Interviewers want judgment, not definitions.`}));
  if(m.missing[0]) qs.push({cat:'Gap',q:`This role uses ${m.missing[0]}. What's your experience with it?`,a:`Be honest, then bridge: mention the closest related skill you have (${m.have[0]||r.skills[0]||'a related tool'}), how fast you've ramped on tools before, and a concrete plan (course, side project) you've already started.`});
  qs.push({cat:'Behavioral',q:'Describe a disagreement with a teammate or manager. How did you handle it?',a:'Show you listen first, use data to decide, and keep the relationship intact. Finish with what the outcome was and what you learned.'});
  qs.push({cat:'Behavioral',q:'Tell me about a mistake you made at work.',a:'Pick a real but recoverable mistake. Own it in one sentence, spend the rest on how you fixed it and the process change you made so it would not happen again.'});
  qs.push({cat:'Company',q:`Why ${job.company}, and why now?`,a:`Reference something specific: "${trim(job.desc.split('. ')[0])}." Connect it to what you want to do next and one way you'd add value in the first 90 days.`});
  qs.push({cat:'Closing',q:'What questions do you have for us?',a:`Ask 2–3: "What does success look like in the first 90 days?", "What's the biggest challenge the team is facing right now?", "How do you measure ${lc(job.title)} performance?"`});
  return qs;
}

function atsScore(r){
  const c=r.contact, bullets=r.experience.flatMap(e=>e.bullets).filter(b=>b.trim());
  const wc = (r.summary||'').trim().split(/\s+/).filter(Boolean).length;
  const quant = bullets.filter(b=>/\d/.test(b)).length;
  const strong = bullets.filter(b=>(VERBS.test(b.trim())||/^[a-z]+ed\b/i.test(b.trim())) && !/^(assisted|helped|handled|supported|performed|provided|worked|was|responsible)\b/i.test(b.trim())).length;
  const checks = [
    {k:'Contact info complete',ok:!!(c.name&&c.email&&c.phone&&c.location),w:12},
    {k:'Headline / target title',ok:!!c.title,w:8},
    {k:'Summary 30–90 words',ok:wc>=30&&wc<=90,w:12,tip:wc?`${wc} words`:'missing'},
    {k:'2+ roles in experience',ok:r.experience.length>=2,w:12},
    {k:'Most bullets start with strong verbs',ok:bullets.length>0&&strong/bullets.length>=0.85,w:14,tip:`${strong}/${bullets.length}`},
    {k:'Half of bullets include numbers',ok:bullets.length>0&&quant/bullets.length>=0.5,w:16,tip:`${quant}/${bullets.length} quantified`},
    {k:'8+ skills listed',ok:r.skills.length>=8,w:10,tip:`${r.skills.length} skills`},
    {k:'Education added',ok:r.education.length>0,w:8},
    {k:'LinkedIn or portfolio link',ok:!!(c.linkedin||c.site),w:8}
  ];
  const score = checks.reduce((a,x)=>a+(x.ok?x.w:0),0);
  return {score,checks};
}

async function callAI(task,payload){
  const ctl = new AbortController(); const t=setTimeout(()=>ctl.abort(),25000);
  try{
    const res = await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({task,payload}),signal:ctl.signal});
    if(!res.ok) throw new Error('ai '+res.status);
    const j = await res.json(); if(j.error) throw new Error(j.error); return j;
  } finally {clearTimeout(t)}
}
async function withFallback(task,payload,local){
  try{ const j = await callAI(task,payload); return {...j,source:'ai'} }
  catch(e){ await new Promise(r=>setTimeout(r,650)); return {...local(),source:'local'} }
}
const slimJob = j => ({title:j.title,company:j.company,desc:j.desc,resp:j.resp,qual:j.qual});

window.NXTC_AI = {
  keywords, match, atsScore, pretty, years, rewrite:improveBullet,
  bullet:(text,resume)=>withFallback('bullet',{text,title:resume.contact.title},()=>({text:improveBullet(text)})),
  summary:(resume)=>withFallback('summary',{resume},()=>({text:localSummary(resume)})),
  cover:(job,resume,tone)=>withFallback('cover',{job:slimJob(job),resume,tone},()=>({text:localCover(job,resume,tone)})),
  interview:(job,resume)=>withFallback('interview',{job:slimJob(job),resume},()=>({items:localInterview(job,resume)}))
};
})();

/* NXT Careers — web app (vanilla JS, no build step). Data lives in this browser (localStorage). */
(function(){
'use strict';
const {JOBS:SAMPLE_JOBS, DEMO_RESUME, BLANK_RESUME} = window.NXTC_DATA;
const AI = window.NXTC_AI;
const CFG = window.NXTC_CONFIG || {};
const KEY = 'nxtc:v1';
const $ = (s,el=document)=>el.querySelector(s);
const $$ = (s,el=document)=>[...el.querySelectorAll(s)];
const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid = () => Math.random().toString(36).slice(2,10);
const clone = o => JSON.parse(JSON.stringify(o));
const today = () => new Date().toISOString().slice(0,10);

/* ---------------- icons ---------------- */
const P = {
 home:'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
 board:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M15 4v10"/>',
 mail:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
 chat:'<path d="M21 12a8 8 0 0 1-11.6 7.1L4 21l1.9-5.4A8 8 0 1 1 21 12z"/>',
 card:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
 gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
 spark:'<path d="M12 3l1.8 4.9L19 9.7l-5.2 1.8L12 16.5l-1.8-5L5 9.7l5.2-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
 plus:'<path d="M12 5v14M5 12h14"/>', x:'<path d="M18 6 6 18M6 6l12 12"/>', check:'<path d="m5 12 5 5L20 7"/>',
 down:'<path d="m6 9 6 6 6-6"/>', left:'<path d="m15 18-6-6 6-6"/>', right:'<path d="m9 6 6 6-6 6"/>',
 pin:'<path d="M12 21s-7-6.2-7-12a7 7 0 0 1 14 0c0 5.8-7 12-7 12z"/><circle cx="12" cy="9" r="2.5"/>',
 brief:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>',
 dollar:'<path d="M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 ext:'<path d="M14 4h6v6M10 14 20 4M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/>',
 bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>',
 trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
 download:'<path d="M12 3v12m0 0-5-5m5 5 5-5M4 19h16"/>', upload:'<path d="M12 21V9m0 0-5 5m5-5 5 5M4 5h16"/>',
 copy:'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/>',
 target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
 trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
 send:'<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
 lock:'<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
 crown:'<path d="m3 7 4 4 5-7 5 7 4-4-2 12H5z"/>',
 cal:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
 bolt:'<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
 print:'<path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2"/><rect x="6" y="14" width="12" height="7"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
 logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
 globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>'
};
const ic = (n,extra='') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ${extra}>${P[n]||''}</svg>`;

/* ---------------- state ---------------- */
const PLANS = {
  free:{name:'No plan',ai:0,apps:0,templates:['modern'],locked:true},
  pro:{name:'Pro',ai:Infinity,apps:Infinity,templates:['modern','bold','classic']},
  pass:{name:'Job Hunt Pass',ai:Infinity,apps:Infinity,templates:['modern','bold','classic']}
};
const STAGES = [
  {k:'saved',n:'Saved',c:'#8b9bb5'},{k:'applied',n:'Applied',c:'#7cc7ff'},{k:'interview',n:'Interview',c:'#ffc21f'},
  {k:'offer',n:'Offer',c:'#3ddc97'},{k:'rejected',n:'Closed',c:'#ff6b7a'}];

let S = load();
function load(){ try{ return JSON.parse(localStorage.getItem(KEY)); }catch(e){ return null; } }
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){} }
function fresh(user, demo){
  const month = today().slice(0,7);
  const st = {
    v:1, created:Date.now(), user, plan:demo?'pro':'free', planUntil:null,
    resume: demo ? clone(DEMO_RESUME) : clone(BLANK_RESUME),
    apps:[], jobs:{}, letters:[], prep:{}, usage:{month,ai:0},
    search:{q:user.target||'',loc:user.location||'',filters:[],results:null,source:null,sel:null},
    goal:10, ui:{open:['contact','experience']}
  };
  if(!demo){ Object.assign(st.resume.contact,{name:user.name,email:user.email,title:user.target,location:user.location}); }
  if(demo){
    st.planUntil = addDays(30);
    const pick = (id,status,daysAgo,extra={}) => { const j=SAMPLE_JOBS.find(x=>x.id===id); st.jobs[id]=j;
      st.apps.push({id:uid(),jobId:id,title:j.title,company:j.company,location:j.location,color:j.color,salary:j.salary,url:'',status,date:addDays(-daysAgo),notes:'',interview:'',...extra}); };
    pick('s1','interview',6,{interview:addDays(2)+'T10:30',notes:'Recruiter screen went well. Tech round with Priya (EM) — review design system story.'});
    pick('s4','interview',9,{interview:addDays(4)+'T14:00'});
    pick('s3','applied',1); pick('s2','applied',3); pick('s16','applied',4); pick('s6','applied',8);
    pick('s17','saved',0); pick('s5','saved',1);
    pick('s12','rejected',14,{notes:'Went with an internal candidate.'});
    pick('s9','offer',20,{notes:'Offer: $96k + bonus. Decide by Friday.'});
    st.usage.ai = 12;
    const j=SAMPLE_JOBS[0];
    st.letters.push({id:uid(),jobId:j.id,title:j.title,company:j.company,tone:'professional',date:addDays(-6),text:''});
  }
  return st;
}
function addDays(n){ const d=new Date(); d.setDate(d.getDate()+n); return d.toISOString().slice(0,10); }
function plan(){
  if(S.plan!=='free' && S.planUntil && S.planUntil < today()){ S.plan='free'; S.planUntil=null; save(); }
  return PLANS[S.plan]||PLANS.free;
}
function aiLeft(){ const m=today().slice(0,7); if(S.usage.month!==m){S.usage={month:m,ai:0};save();} const p=plan(); return p.ai===Infinity?Infinity:Math.max(0,p.ai-S.usage.ai); }
function spendAI(){ if(aiLeft()<=0){ upgradeModal('AI writing is included with Pro and the Job Hunt Pass.'); return false; } S.usage.ai++; save(); return true; }
const allJobs = () => { const m={}; SAMPLE_JOBS.forEach(j=>m[j.id]=j); Object.assign(m,S.jobs); (S.search.results||[]).forEach(j=>m[j.id]=j); return m; };
const matchOf = j => AI.match(j,S.resume);
const mClass = s => s>=75?'m-hi':s>=55?'m-md':'m-lo';
const ago = iso => { const d=Math.floor((Date.now()-new Date(iso))/864e5); return d<=0?'Today':d===1?'1d ago':d<30?d+'d ago':Math.floor(d/30)+'mo ago'; };
const fmtDate = s => s ? new Date(s.length<=10?s+'T12:00':s).toLocaleDateString(undefined,{month:'short',day:'numeric'}) : '';
const fmtDT = s => s ? new Date(s).toLocaleString(undefined,{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}) : '';
const initials = s => (s||'?').split(/\s+/).map(w=>w[0]).slice(0,2).join('').toUpperCase();
const coLogo = (j,size=38) => j.logo ? `<img class="logo-sq" style="width:${size}px;height:${size}px;background:#fff;object-fit:contain;padding:4px" src="${esc(j.logo)}" alt="">` : `<div class="logo-sq" style="width:${size}px;height:${size}px;background:${j.color||'#2b86f0'}">${esc(initials(j.company))}</div>`;

/* ---------------- toast / modal ---------------- */
function toast(msg,icon='check'){ const t=document.createElement('div'); t.className='toast'; t.innerHTML=ic(icon)+esc(msg); $('#toasts').append(t); setTimeout(()=>t.remove(),2800); }
function modal({title,body,foot='',wide=false,onMount}){
  closeModal();
  const bg=document.createElement('div'); bg.className='modal-bg'; bg.id='modal';
  bg.innerHTML=`<div class="modal" style="${wide?'max-width:760px':''}"><div class="modal-h"><h3>${title}</h3><button class="icon-btn" data-close>${ic('x')}</button></div><div class="modal-b">${body}</div>${foot?`<div class="modal-f">${foot}</div>`:''}</div>`;
  bg.addEventListener('click',e=>{ if(e.target===bg||e.target.closest('[data-close]')) closeModal(); });
  document.body.append(bg); onMount&&onMount(bg); return bg;
}
function closeModal(){ $('#modal')?.remove(); }
function upgradeModal(reason){
  modal({title:'Upgrade to keep going',body:`<div class="row" style="gap:16px;align-items:flex-start"><img src="/assets/logo-256.png" style="width:76px" alt=""><div><p style="margin-bottom:8px">${esc(reason||'This feature is part of NXT Careers Pro.')}</p><p class="muted">Pro and the Job Hunt Pass unlock unlimited AI writing, all resume templates, unlimited tracking and interview prep.</p></div></div>`,
    foot:`<button class="btn btn-ghost" data-close>Not now</button><a class="btn btn-primary" href="#/billing" data-close>${ic('crown')}See plans</a>`});
}

/* ---------------- routing ---------------- */
const ROUTES = {
  dashboard:{t:'Dashboard',s:'Your job search at a glance',i:'home',v:vDashboard},
  jobs:{t:'Job Search',s:'Live listings from Indeed, LinkedIn, Glassdoor & more',i:'search',v:vJobs},
  resume:{t:'Resume Builder',s:'ATS-friendly resumes with AI writing help',i:'file',v:vResume},
  tracker:{t:'Applications',s:'Track every application from saved to offer',i:'board',v:vTracker},
  letters:{t:'Cover Letters',s:'Tailored letters in seconds',i:'mail',v:vLetters},
  interview:{t:'Interview Prep',s:'Likely questions and answer plans for each job',i:'chat',v:vInterview},
  billing:{t:'Plans & Billing',s:'Upgrade, manage and verify your plan',i:'card',v:vBilling},
  settings:{t:'Settings',s:'Profile, data and connections',i:'gear',v:vSettings},
  more:{t:'More',s:'',i:'grid',v:vMore}
};
function route(){ const h=location.hash.replace(/^#\/?/,''); const [p,qs]=h.split('?'); return {name:ROUTES[p]?p:'dashboard',params:new URLSearchParams(qs||'')}; }
window.addEventListener('hashchange',()=>{ closeModal(); render(); window.scrollTo(0,0); });

function render(){
  const root=$('#root');
  if(!S){ root.innerHTML=vOnboarding(); bindOnboarding(); return; }
  const r=route(), R=ROUTES[r.name], p=plan();
  const cnt = S.apps.filter(a=>a.status!=='saved'&&a.status!=='rejected').length;
  const link=(k,extra='')=>`<a href="#/${k}" class="${r.name===k?'active':''}">${ic(ROUTES[k].i)}<span>${ROUTES[k].t}</span>${extra}</a>`;
  root.innerHTML = `<div class="shell">
  <aside class="sidebar">
    <a class="brand" href="/"><img src="/assets/logo-256.png" alt="NXT Careers"><div><b>NXT <span>Careers</span></b><small>by NXT Cloud</small></div></a>
    <nav class="nav">
      ${link('dashboard')}${link('jobs')}${link('resume')}${link('tracker',`<span class="count">${cnt}</span>`)}
      <div class="sec">AI tools</div>${link('letters')}${link('interview')}
      <div class="sec">Account</div>${link('billing')}${link('settings')}
    </nav>
    <div class="sb-foot">
      ${S.plan==='free'?`<div class="plan-card"><b>${ic('lock','style="width:15px;height:15px;color:var(--yellow)"')} Preview mode</b><p>Choose a plan to unlock AI writing, PDF downloads, tracking and interview prep.</p><a href="#/billing" class="btn btn-hat btn-sm btn-block">Choose a plan</a></div>`
        :`<div class="plan-card"><b>${ic('crown','style="width:15px;height:15px;color:var(--yellow)"')} ${p.name}</b><p style="margin-bottom:0">Unlimited AI · ${S.planUntil?(S.plan==='pass'?'Ends ':'Renews ')+fmtDate(S.planUntil):'Active'}</p></div>`}
      <div class="me"><div class="avatar">${esc(initials(S.user.name))}</div><div><b>${esc(S.user.name)}</b><small>${esc(S.user.target||S.user.email||'')}</small></div></div>
    </div>
  </aside>
  <main class="main">
    <header class="topbar">
      <img class="mob-brand" src="/assets/logo-256.png" alt="">
      <div><h1>${R.t}</h1>${R.s?`<div class="sub">${R.s}</div>`:''}</div>
      <div class="spacer"></div>
      <form class="search" id="gsearch">${ic('search','style="width:16px;height:16px"')}<input placeholder="Search jobs, e.g. React developer" value=""></form>
      <a class="icon-btn" href="#/settings" title="Settings">${ic('user')}</a>
    </header>
    <div class="page" id="view">${R.v(r.params)}</div>
  </main>
  <nav class="bottom-nav">
    ${['dashboard','jobs','resume','tracker','more'].map(k=>`<a href="#/${k}" class="${r.name===k||(k==='more'&&['letters','interview','billing','settings'].includes(r.name))?'active':''}">${ic(ROUTES[k].i)}<span>${k==='dashboard'?'Home':k==='tracker'?'Tracker':k==='jobs'?'Jobs':ROUTES[k].t.split(' ')[0]}</span></a>`).join('')}
  </nav></div>`;
  $('#gsearch').addEventListener('submit',e=>{e.preventDefault(); const q=e.target.querySelector('input').value.trim(); if(q){S.search.q=q;S.search.results=null;S.search.sel=null;save();location.hash='#/jobs';}});
  const after = BIND[r.name]; after && after(r.params);
}

/* ---------------- onboarding ---------------- */
function vOnboarding(){
  return `<div class="onb"><div class="onb-card">
  <img src="/assets/logo.png" alt="NXT Careers">
  <h1>Welcome to NXT <span style="color:var(--blue)">Careers</span></h1>
  <p>Build a standout resume, find jobs, and track every application in one place.</p>
  <form class="card stack" id="onb">
    <div class="form-grid">
      <div class="field"><label>Full name</label><input class="input" name="name" required placeholder="Jordan Rivera"></div>
      <div class="field"><label>Email</label><input class="input" name="email" type="email" placeholder="you@email.com"></div>
      <div class="field"><label>Target role</label><input class="input" name="target" placeholder="e.g. Frontend Engineer"></div>
      <div class="field"><label>Location</label><input class="input" name="location" placeholder="e.g. Dallas, TX"></div>
    </div>
    <button class="btn btn-primary btn-block" type="submit">Get started ${ic('right')}</button>
    <button class="btn btn-ghost btn-block" type="button" id="demo">${ic('spark')} Explore with a sample profile</button>
    <p class="dim" style="font-size:12px;text-align:center">Your data stays private in this browser. Export it any time from Settings.</p>
  </form></div></div>`;
}
function bindOnboarding(){
  $('#onb').addEventListener('submit',e=>{ e.preventDefault(); const f=Object.fromEntries(new FormData(e.target)); S=fresh(f,false); save(); location.hash='#/billing'; render(); toast('Account created — pick a plan to unlock everything','crown'); checkPendingPayment(); });
  $('#demo').addEventListener('click',()=>{ S=fresh({name:'Jordan Rivera',email:'jordan.rivera@email.com',target:'Frontend Engineer',location:'Dallas, TX'},true); save(); location.hash='#/dashboard'; render(); });
}

/* ---------------- dashboard ---------------- */
function vDashboard(){
  const a=S.apps, n=k=>a.filter(x=>x.status===k).length;
  const sent=a.filter(x=>x.status!=='saved').length, responded=a.filter(x=>['interview','offer'].includes(x.status)).length;
  const rate=sent?Math.round(responded/sent*100):0;
  const ats=AI.atsScore(S.resume);
  const weekAgo=addDays(-7), thisWeek=a.filter(x=>x.status!=='saved'&&x.date>=weekAgo).length;
  const first=(S.user.name||'there').split(' ')[0];
  const hr=new Date().getHours(), greet=hr<12?'Good morning':hr<18?'Good afternoon':'Good evening';
  const left=Math.max(0,S.goal-thisWeek);
  const recs=Object.values(allJobs()).map(j=>({j,m:matchOf(j)})).filter(x=>!a.some(ap=>ap.jobId===x.j.id)).sort((x,y)=>y.m.score-x.m.score).slice(0,5);
  const upcoming=a.filter(x=>x.status==='interview'&&x.interview).sort((x,y)=>x.interview.localeCompare(y.interview));
  const recent=[...a].sort((x,y)=>y.date.localeCompare(x.date)).slice(0,5);
  const R=2*Math.PI*54, off=R*(1-ats.score/100);
  return `
  <section class="hello">
    <img src="/assets/logo.png" alt="">
    <div><h2>${greet}, ${esc(first)}</h2>
      <p>${left?`You're <b style="color:var(--text)">${left} application${left>1?'s':''}</b> away from this week's goal.`:'You hit this week’s application goal — nice work.'} ${upcoming.length?`Next interview: <b style="color:var(--text)">${esc(upcoming[0].company)}</b>, ${fmtDT(upcoming[0].interview)}.`:''}</p>
      <div class="row"><a href="#/jobs" class="btn btn-primary">${ic('search')}Find jobs</a><a href="#/resume" class="btn btn-ghost">${ic('spark')}Improve resume</a></div></div>
  </section>
  <div class="grid g4" style="margin-top:16px">
    ${stat('send','Applications sent',sent,thisWeek?`+${thisWeek} this week`:'')}
    ${stat('chat','Interviews',n('interview'),upcoming.length?`${upcoming.length} upcoming`:'')}
    ${stat('target','Response rate',rate+'%',rate>=20?'Above average':'')}
    ${stat('trophy','Offers',n('offer'),n('offer')?'Congrats!':'')}
  </div>
  <div class="grid g3" style="margin-top:16px">
    <div class="card"><div class="card-h"><h3>Pipeline</h3><a href="#/tracker" class="muted">Open tracker →</a></div>
      <div class="funnel">${STAGES.map(s=>{const c=n(s.k);return `<div class="fr"><span class="row" style="gap:7px"><i class="dot" style="background:${s.c}"></i>${s.n}</span><div class="bar"><i style="width:${a.length?Math.max(4,c/a.length*100):0}%;background:${s.c}"></i></div><b style="text-align:right">${c}</b></div>`}).join('')}</div></div>
    <div class="card"><div class="card-h"><h3>Resume strength</h3><a href="#/resume" class="muted">Edit →</a></div>
      <div class="row" style="gap:18px;align-items:center">
        <div class="ring"><svg width="132" height="132"><circle cx="66" cy="66" r="54" stroke="#172033" stroke-width="12" fill="none"/><circle cx="66" cy="66" r="54" stroke="url(#rg)" stroke-width="12" fill="none" stroke-linecap="round" stroke-dasharray="${R}" stroke-dashoffset="${off}"/><defs><linearGradient id="rg"><stop offset="0" stop-color="#4aa8ff"/><stop offset="1" stop-color="#9ad6ff"/></linearGradient></defs></svg><div class="num"><div><b>${ats.score}</b><small>ATS score</small></div></div></div>
        <div style="flex:1;min-width:0">${ats.checks.filter(c=>!c.ok).slice(0,3).map(c=>`<div class="check"><span class="ci no">${ic('bolt')}</span><span>${c.k}${c.tip?` <span class="dim">(${c.tip})</span>`:''}</span></div>`).join('')||`<div class="check"><span class="ci ok">${ic('check')}</span>All checks passed</div>`}
        ${ats.checks.filter(c=>c.ok).slice(0,2).map(c=>`<div class="check"><span class="ci ok">${ic('check')}</span><span>${c.k}</span></div>`).join('')}</div>
      </div></div>
    <div class="card"><div class="card-h"><h3>Weekly goal</h3><button class="muted" id="goalEdit">Edit</button></div>
      <div style="font-size:34px;font-weight:800;letter-spacing:-.03em">${thisWeek}<span class="muted" style="font-size:16px;font-weight:500"> / ${S.goal} applications</span></div>
      <div class="bar" style="height:12px;margin:12px 0 16px"><i style="width:${Math.min(100,thisWeek/S.goal*100)}%;background:linear-gradient(90deg,#f5a70f,#ffd24d)"></i></div>
      <div class="row" style="gap:6px">${[6,5,4,3,2,1,0].map(d=>{const day=addDays(-d);const c=a.filter(x=>x.status!=='saved'&&x.date===day).length;return `<div style="flex:1;text-align:center"><div style="height:44px;display:flex;align-items:flex-end;justify-content:center"><i style="display:block;width:100%;max-width:26px;border-radius:6px;height:${6+c*14}px;background:${c?'var(--blue2)':'var(--surface3)'}"></i></div><small class="dim">${new Date(day+'T12:00').toLocaleDateString(undefined,{weekday:'narrow'})}</small></div>`}).join('')}</div>
    </div>
  </div>
  <div class="grid g2" style="margin-top:16px">
    <div class="card"><div class="card-h"><h3>Top matches for you</h3><a href="#/jobs" class="muted">See all →</a></div>
      ${recs.map(({j,m})=>`<a class="list-item" href="#/jobs?id=${esc(j.id)}" style="color:inherit">${coLogo(j)}<div class="li-main"><b>${esc(j.title)}</b><small>${esc(j.company)} · ${esc(j.location)}${j.salary?' · '+esc(j.salary):''}</small></div><span class="match ${mClass(m.score)}">${m.score}%</span></a>`).join('')}
    </div>
    <div class="card"><div class="card-h"><h3>Upcoming & recent</h3><a href="#/tracker" class="muted">All →</a></div>
      ${upcoming.map(x=>`<div class="list-item">${coLogo(x)}<div class="li-main"><b>Interview · ${esc(x.company)}</b><small>${esc(x.title)} · ${fmtDT(x.interview)}</small></div><a class="btn btn-sm btn-ghost" href="#/interview?job=${esc(x.jobId)}">Prep</a></div>`).join('')}
      ${recent.filter(x=>!upcoming.includes(x)).slice(0,5-upcoming.length).map(x=>{const s=STAGES.find(s=>s.k===x.status);return `<div class="list-item">${coLogo(x)}<div class="li-main"><b>${esc(x.title)}</b><small>${esc(x.company)} · ${fmtDate(x.date)}</small></div><span class="chip" style="color:${s.c}"><i class="dot" style="background:${s.c}"></i>${s.n}</span></div>`}).join('')||'<div class="empty">No applications yet.</div>'}
    </div>
  </div>`;
}
function stat(i,l,v,d){ return `<div class="card stat"><div class="lbl">${ic(i)}${l}</div><div class="val">${v}</div><div class="delta">${d||'&nbsp;'}</div></div>`; }

/* ---------------- jobs ---------------- */
const FILTERS=[['remote','Remote'],['Full-time','Full-time'],['Contract','Contract'],['Part-time','Part-time'],['3d','Past 3 days'],['80','80%+ match']];
function vJobs(params){
  const s=S.search;
  if(params.get('id')) s.sel=params.get('id');
  const res=filteredJobs();
  const sel=s.sel && allJobs()[s.sel];
  return `
  <form class="jobs-bar" id="jform">
    <div class="ico-input">${ic('search')}<input class="input" name="q" placeholder="Job title, skill or company" value="${esc(s.q)}"></div>
    <div class="ico-input">${ic('pin')}<input class="input" name="loc" placeholder="City, state or Remote" value="${esc(s.loc)}"></div>
    <button class="btn btn-primary" type="submit">${ic('search')}Search jobs</button>
  </form>
  <div class="filters">${FILTERS.map(([k,l])=>`<button class="fchip ${s.filters.includes(k)?'on':''}" data-f="${k}">${l}</button>`).join('')}
    <span class="src" style="margin-left:auto;align-self:center" id="srcNote">${srcNote()}</span></div>
  <div class="jobs-layout ${sel?'has-sel':''}" id="jl">
    <div class="job-list" id="jlist">${res===null?loadingCards():res.length?res.map(({j,m})=>jobCard(j,m,sel)).join(''):`<div class="card empty"><img src="/assets/logo-256.png" alt=""><h4>No jobs match those filters</h4><p>Try a broader title or remove a filter.</p></div>`}</div>
    <div class="card job-detail" id="jdetail">${sel?jobDetail(sel):`<div class="empty"><img src="/assets/logo-256.png" alt=""><h4>Pick a job</h4><p>Select a listing to see details, your match score and one-click tools.</p></div>`}</div>
  </div>`;
}
function srcNote(){ const s=S.search.source; return s==='live'?`<span class="row" style="gap:6px"><i class="dot" style="background:var(--green)"></i>Live results via JSearch</span>`:s==='sample'?`Showing sample listings · connect the job API to go live`:''; }
function loadingCards(){ return Array.from({length:5},()=>`<div class="job-card"><div style="flex:1"><div class="shimmer" style="width:60%"></div><div class="shimmer" style="width:40%"></div><div class="shimmer" style="width:80%"></div></div></div>`).join(''); }
function jobCard(j,m,sel){
  const tracked=S.apps.some(a=>a.jobId===j.id);
  return `<div class="job-card ${sel&&sel.id===j.id?'sel':''}" data-job="${esc(j.id)}">${coLogo(j,42)}<div class="jc-main">
    <div class="row between" style="align-items:flex-start"><h4>${esc(j.title)}</h4><span class="match ${mClass(m.score)}">${m.score}%</span></div>
    <div class="co">${esc(j.company)} · ${esc(j.location)}</div>
    <div class="meta">${j.remote?'<span class="chip blue">Remote</span>':''}<span class="chip">${esc(j.type)}</span>${j.salary?`<span class="chip green">${esc(j.salary)}</span>`:''}<span class="chip">${ago(j.posted)}</span>${tracked?'<span class="chip yellow">Tracked</span>':''}</div>
  </div></div>`;
}
function jobDetail(j){
  const m=matchOf(j), tracked=S.apps.find(a=>a.jobId===j.id);
  return `<button class="btn btn-quiet btn-sm mob-only" id="jback" style="margin:-6px 0 8px -8px">${ic('left')}Back to results</button>
  <div class="jd-head">${coLogo(j,54)}<div style="flex:1;min-width:0"><h2>${esc(j.title)}</h2><div class="muted">${esc(j.company)} · ${esc(j.location)}</div>
    <div class="meta row wrap" style="gap:6px;margin-top:8px">${j.remote?'<span class="chip blue">Remote</span>':''}<span class="chip">${esc(j.type)}</span>${j.salary?`<span class="chip green">${esc(j.salary)}</span>`:''}<span class="chip">${ic('clock','style="width:12px;height:12px"')}${ago(j.posted)}</span>${j.publisher?`<span class="chip">via ${esc(j.publisher)}</span>`:''}</div></div></div>
  <div class="row wrap" style="margin:16px 0">
    <button class="btn btn-primary" data-act="apply">${ic('ext')}Apply now</button>
    <button class="btn btn-ghost" data-act="track">${ic('bookmark')}${tracked?'Tracked · '+STAGES.find(s=>s.k===tracked.status).n:'Save to tracker'}</button>
    <button class="btn btn-ghost" data-act="letter">${ic('mail')}Cover letter</button>
    <button class="btn btn-ghost" data-act="prep">${ic('chat')}Interview prep</button>
  </div>
  <div class="card" style="background:var(--bg2);padding:14px 16px">
    <div class="row between"><b>Resume match</b><span class="match ${mClass(m.score)}" style="font-size:15px">${m.score}%</span></div>
    <div class="bar" style="margin:10px 0 12px"><i style="width:${m.score}%"></i></div>
    ${m.have.length?`<div class="dim" style="font-size:12px;margin-bottom:6px">You have</div><div class="kw">${m.have.map(k=>`<span class="chip green">${ic('check','style="width:11px;height:11px"')}${esc(k)}</span>`).join('')}</div>`:''}
    ${m.missing.length?`<div class="dim" style="font-size:12px;margin:10px 0 6px">Missing from your resume</div><div class="kw">${m.missing.map(k=>`<button class="chip yellow" data-addskill="${esc(k)}" title="Add to skills">${ic('plus','style="width:11px;height:11px"')}${esc(k)}</button>`).join('')}</div><div class="dim" style="font-size:11.5px;margin-top:8px">Tap a missing keyword to add it to your skills — only add skills you really have.</div>`:''}
  </div>
  <div class="jd-body" style="margin-top:16px">
    <p>${esc(j.desc)}</p>
    ${j.resp?.length?`<h5>Responsibilities</h5><ul>${j.resp.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
    ${j.qual?.length?`<h5>Qualifications</h5><ul>${j.qual.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
    ${j.benefits?.length?`<h5>Benefits</h5><ul>${j.benefits.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
  </div>`;
}
function filteredJobs(){
  const s=S.search; if(!s.results) return null;
  let r=s.results.map(j=>({j,m:matchOf(j)}));
  const f=s.filters;
  if(f.includes('remote')) r=r.filter(x=>x.j.remote);
  const types=['Full-time','Contract','Part-time'].filter(t=>f.includes(t)); if(types.length) r=r.filter(x=>types.includes(x.j.type));
  if(f.includes('3d')) r=r.filter(x=>Date.now()-new Date(x.j.posted)<=3.5*864e5);
  if(f.includes('80')) r=r.filter(x=>x.m.score>=80);
  return r.sort((a,b)=>b.m.score-a.m.score || new Date(b.j.posted)-new Date(a.j.posted));
}
async function runSearch(){
  const s=S.search; s.results=null; const list=$('#jlist'); if(list) list.innerHTML=loadingCards();
  const qs=new URLSearchParams({query:s.q||S.resume.contact.title||'jobs',location:s.loc||''});
  if(s.filters.includes('remote')) qs.set('remote','1');
  try{
    const ctl=new AbortController(); setTimeout(()=>ctl.abort(),15000);
    const res=await fetch('/api/jobs?'+qs,{signal:ctl.signal}); if(!res.ok) throw 0;
    const j=await res.json(); if(!j.jobs||j.source!=='live') throw 0;
    s.results=j.jobs; s.source='live';
  }catch(e){
    const q=(s.q||'').toLowerCase().split(/\s+/).filter(w=>w.length>1), loc=(s.loc||'').toLowerCase();
    let r=SAMPLE_JOBS.map(j=>{const t=(j.title+' '+j.company+' '+j.desc+' '+(j.qual||[]).join(' ')).toLowerCase();return {j,h:q.filter(w=>t.includes(w)).length+(q.some(w=>j.title.toLowerCase().includes(w))?2:0)}});
    if(q.length) r=r.filter(x=>x.h>0);
    if(loc && !/remote/.test(loc)){ const city=loc.split(',')[0].trim(); const st=(loc.split(',')[1]||'').trim(); r=r.filter(x=>x.j.remote||x.j.location.toLowerCase().includes(city)||(st&&x.j.location.toLowerCase().includes(', '+st))); }
    if(!r.length) r=SAMPLE_JOBS.map(j=>({j,h:0}));
    s.results=r.map(x=>x.j); s.source='sample';
  }
  save(); if(route().name==='jobs') refreshJobs();
}
function refreshJobs(){
  const res0=filteredJobs(); if(res0&&res0.length&&!S.search.sel&&innerWidth>900){ S.search.sel=res0[0].j.id; save(); }
  const res=res0, sel=S.search.sel&&allJobs()[S.search.sel];
  $('#jlist').innerHTML = res===null?loadingCards():res.length?res.map(({j,m})=>jobCard(j,m,sel)).join(''):`<div class="card empty"><h4>No jobs match those filters</h4><p>Try a broader title or remove a filter.</p></div>`;
  $('#jdetail').innerHTML = sel?jobDetail(sel):`<div class="empty"><img src="/assets/logo-256.png" alt=""><h4>Pick a job</h4><p>Select a listing to see details, your match score and one-click tools.</p></div>`;
  $('#jl').classList.toggle('has-sel',!!sel);
  $('#srcNote').innerHTML=srcNote();
  $$('.fchip').forEach(b=>b.classList.toggle('on',S.search.filters.includes(b.dataset.f)));
}
function trackJob(j,status='saved'){
  let a=S.apps.find(x=>x.jobId===j.id);
  if(!a){
    if(S.apps.length>=plan().apps){ upgradeModal('Applying and tracking jobs is included with Pro and the Job Hunt Pass.'); return null; }
    S.jobs[j.id]=j;
    a={id:uid(),jobId:j.id,title:j.title,company:j.company,location:j.location,color:j.color||'#2b86f0',logo:j.logo||'',salary:j.salary||'',url:j.apply||'',status,date:today(),notes:'',interview:''};
    S.apps.push(a);
  } else if(status==='applied' && a.status==='saved'){ a.status='applied'; a.date=today(); }
  save(); return a;
}
function applyUrl(j){ return j.apply || ('https://www.google.com/search?q='+encodeURIComponent(j.title+' '+j.company+' jobs apply')); }

/* ---------------- resume ---------------- */
function vResume(){
  const r=S.resume, o=S.ui.open, ats=AI.atsScore(r), p=plan();
  const sec=(k,title,body,extra='')=>`<div class="card ${o.includes(k)?'open':''}" data-sec="${k}"><div class="card-h"><h3>${title}</h3><div class="row">${extra}${ic('down','class="chev" style="width:18px;height:18px"')}</div></div><div class="sec-body">${body}</div></div>`;
  const f=(path,label,ph='',full=false)=>`<div class="field ${full?'full':''}"><label>${label}</label><input class="input" data-b="${path}" value="${esc(get(r,path))}" placeholder="${ph}"></div>`;
  return `<div class="rb">
  <div class="rb-edit">
    <div class="card row between wrap" style="margin-bottom:14px;padding:14px 16px">
      <div class="row"><span class="match ${mClass(ats.score)}" style="font-size:15px">${ats.score}</span><div><b>ATS score</b><div class="dim" style="font-size:12px">${ats.checks.filter(c=>!c.ok).length} suggestion${ats.checks.filter(c=>!c.ok).length===1?'':'s'} to improve</div></div></div>
      <div class="row"><button class="btn btn-ghost btn-sm" id="atsTips">${ic('bolt')}Tips</button><span class="chip yellow">${ic('spark','style="width:12px;height:12px"')}${aiLeft()===Infinity?'Unlimited AI':'AI locked'}</span></div>
    </div>
    ${sec('contact','Contact',`<div class="form-grid">${f('contact.name','Full name','Jordan Rivera')}${f('contact.title','Headline / title','Frontend Engineer')}${f('contact.email','Email','you@email.com')}${f('contact.phone','Phone','(555) 555-5555')}${f('contact.location','Location','City, ST')}${f('contact.linkedin','LinkedIn','linkedin.com/in/you')}${f('contact.site','Website / portfolio','yoursite.com',true)}</div>`)}
    ${sec('summary','Professional summary',`<textarea class="textarea" data-b="summary" rows="4" placeholder="2–3 sentences: who you are, your strongest results, what you want next.">${esc(r.summary)}</textarea><div class="row between" style="margin-top:8px"><span class="dim" style="font-size:12px">${(r.summary||'').split(/\s+/).filter(Boolean).length} words · aim for 30–90</span><button class="btn btn-sm btn-ghost" id="aiSummary" style="color:var(--yellow)">${ic('spark')}Write with AI</button></div>`)}
    ${sec('experience','Experience',r.experience.map((e,i)=>`<div class="entry"><div class="entry-h"><b>${esc(e.role||'New role')}${e.company?' · '+esc(e.company):''}</b><div class="row" style="gap:4px"><button class="icon-btn" style="width:30px;height:30px" data-mv="experience.${i}.-1" title="Move up">${ic('down','style="width:15px;height:15px;transform:rotate(180deg)"')}</button><button class="icon-btn" style="width:30px;height:30px" data-del="experience.${i}" title="Remove">${ic('trash','style="width:15px;height:15px"')}</button></div></div>
      <div class="form-grid">${f(`experience.${i}.role`,'Job title')}${f(`experience.${i}.company`,'Company')}${f(`experience.${i}.start`,'Start','Mar 2023')}${f(`experience.${i}.end`,'End','Present')}</div>
      <div class="field" style="margin-top:12px"><label>Achievements</label>${e.bullets.map((b,k)=>`<div class="bullet-row"><textarea class="textarea" rows="1" data-b="experience.${i}.bullets.${k}" placeholder="Led X, which achieved Y (measured by Z)">${esc(b)}</textarea><button class="ai-btn" data-aib="${i}.${k}" title="Improve with AI">${ic('spark')}</button><button class="ai-btn" style="color:var(--dim);border-color:var(--border2);background:none" data-del="experience.${i}.bullets.${k}" title="Remove">${ic('x')}</button></div>`).join('')}
      <button class="btn btn-quiet btn-sm" data-addb="${i}" style="align-self:flex-start">${ic('plus')}Add bullet</button></div></div>`).join('')+`<button class="btn btn-ghost btn-sm" id="addExp">${ic('plus')}Add position</button>`,`<span class="chip">${r.experience.length}</span>`)}
    ${sec('education','Education',r.education.map((e,i)=>`<div class="entry"><div class="entry-h"><b>${esc(e.school||'School')}</b><button class="icon-btn" style="width:30px;height:30px" data-del="education.${i}">${ic('trash','style="width:15px;height:15px"')}</button></div><div class="form-grid">${f(`education.${i}.school`,'School')}${f(`education.${i}.degree`,'Degree / certificate')}${f(`education.${i}.start`,'Start')}${f(`education.${i}.end`,'End')}${f(`education.${i}.detail`,'Details (honors, GPA, activities)','',true)}</div></div>`).join('')+`<button class="btn btn-ghost btn-sm" id="addEdu">${ic('plus')}Add education</button>`)}
    ${sec('skills','Skills',`<div class="skills-in" id="skillsBox">${r.skills.map((s,i)=>`<span class="skill-tag">${esc(s)}<button data-del="skills.${i}">${ic('x','style="width:11px;height:11px"')}</button></span>`).join('')}<input id="skillIn" placeholder="Type a skill and press Enter"></div>`,`<span class="chip">${r.skills.length}</span>`)}
    ${sec('projects','Projects & certifications',r.projects.map((e,i)=>`<div class="entry"><div class="entry-h"><b>${esc(e.name||'Project')}</b><button class="icon-btn" style="width:30px;height:30px" data-del="projects.${i}">${ic('trash','style="width:15px;height:15px"')}</button></div><div class="form-grid">${f(`projects.${i}.name`,'Name')}${f(`projects.${i}.link`,'Link')}<div class="field full"><label>Description</label><textarea class="textarea" rows="2" data-b="projects.${i}.detail">${esc(e.detail)}</textarea></div></div></div>`).join('')+`<button class="btn btn-ghost btn-sm" id="addProj">${ic('plus')}Add project</button>`)}
  </div>
  <div class="rb-preview">
    <div class="row between wrap" style="margin-bottom:10px">
      <div class="tpl-pick">${['modern','bold','classic'].map(t=>`<button data-tpl="${t}" class="${r.template===t?'on':''}">${t[0].toUpperCase()+t.slice(1)}${p.templates.includes(t)?'':' '+ic('lock','style="width:11px;height:11px;vertical-align:-1px"')}</button>`).join('')}</div>
      <button class="btn btn-primary btn-sm" id="pdf">${ic('download')}Download PDF</button>
    </div>
    <div class="paper-wrap"><div id="paperSlot">${paper(r)}</div></div>
  </div></div>`;
}
function paper(r){
  const c=r.contact;
  const contact=[c.email,c.phone,c.location,c.linkedin,c.site].filter(Boolean).map(esc).map(x=>`<span>${x}</span>`).join('');
  const head=`<h1>${esc(c.name||'Your Name')}</h1>${c.title?`<div class="p-title">${esc(c.title)}</div>`:''}<div class="p-contact">${contact}</div>`;
  const body=`${r.summary?`<h3>Summary</h3><p>${esc(r.summary)}</p>`:''}
  ${r.experience.length?`<h3>Experience</h3>${r.experience.map(e=>`<div class="p-job"><div class="p-job-h"><b>${esc(e.role)}</b><span>${esc([e.start,e.end].filter(Boolean).join(' – '))}</span></div><div class="p-co">${esc([e.company,e.location].filter(Boolean).join(' · '))}</div><ul>${e.bullets.filter(b=>b.trim()).map(b=>`<li>${esc(b)}</li>`).join('')}</ul></div>`).join('')}`:''}
  ${r.skills.length?`<h3>Skills</h3><div class="p-skills">${r.skills.map(s=>`<span>${esc(s)}</span>`).join('')}</div>`:''}
  ${r.projects.length?`<h3>Projects</h3>${r.projects.map(p=>`<div class="p-job"><div class="p-job-h"><b>${esc(p.name)}</b><span>${esc(p.link)}</span></div><div>${esc(p.detail)}</div></div>`).join('')}`:''}
  ${r.education.length?`<h3>Education</h3>${r.education.map(e=>`<div class="p-job"><div class="p-job-h"><b>${esc(e.degree)}</b><span>${esc([e.start,e.end].filter(Boolean).join(' – '))}</span></div><div class="p-co">${esc(e.school)}${e.detail?' · '+esc(e.detail):''}</div></div>`).join('')}`:''}`;
  const t=r.template||'modern';
  return t==='bold'?`<div class="paper t-bold" id="printable"><div class="p-top">${head}</div><div class="p-rest">${body}</div></div>`:`<div class="paper t-${t}" id="printable">${head}${body}</div>`;
}
function get(o,path){ return path.split('.').reduce((a,k)=>a==null?a:a[k],o)??''; }
function set(o,path,v){ const ks=path.split('.'); const last=ks.pop(); const t=ks.reduce((a,k)=>a[k],o); t[last]=v; }
function del(o,path){ const ks=path.split('.'); const last=+ks.pop(); ks.reduce((a,k)=>a[k],o).splice(last,1); }
function rerenderResume(){ const y=window.scrollY; $('#view').innerHTML=vResume(); BIND.resume(); window.scrollTo(0,y); }
function refreshPaper(){ $('#paperSlot').innerHTML=paper(S.resume); }

/* ---------------- tracker ---------------- */
function vTracker(){
  const a=S.apps;
  return `<div class="row between wrap" style="margin-bottom:16px">
    <div class="row wrap">${STAGES.map(s=>`<span class="chip"><i class="dot" style="background:${s.c}"></i>${s.n} <b style="color:var(--text)">${a.filter(x=>x.status===s.k).length}</b></span>`).join('')}</div>
    <div class="row"><button class="btn btn-ghost" id="csv">${ic('download')}Export CSV</button><button class="btn btn-primary" id="addApp">${ic('plus')}Add application</button></div></div>
  <div class="board">${STAGES.map(s=>{const items=a.filter(x=>x.status===s.k).sort((x,y)=>y.date.localeCompare(x.date));return `<div class="col" data-col="${s.k}"><div class="col-h"><i class="dot" style="background:${s.c}"></i>${s.n}<span class="n">${items.length}</span></div><div class="col-body">${items.map(tcard).join('')||`<div class="dim" style="font-size:12.5px;text-align:center;padding:20px 6px;border:1px dashed var(--border2);border-radius:10px">Drag cards here</div>`}</div></div>`}).join('')}</div>
  <div class="tlist">${STAGES.map(s=>{const items=a.filter(x=>x.status===s.k);return items.length?`<div style="margin-bottom:18px"><div class="col-h"><i class="dot" style="background:${s.c}"></i>${s.n}<span class="n">${items.length}</span></div><div class="card" style="padding:4px 14px">${items.map(x=>`<div class="list-item" data-app="${x.id}" style="cursor:pointer">${coLogo(x)}<div class="li-main"><b>${esc(x.title)}</b><small>${esc(x.company)} · ${x.status==='interview'&&x.interview?fmtDT(x.interview):fmtDate(x.date)}</small></div>${ic('right','style="width:18px;height:18px;color:var(--dim)"')}</div>`).join('')}</div></div>`:''}).join('')||`<div class="card empty"><img src="/assets/logo-256.png" alt=""><h4>No applications yet</h4><p>Save jobs from search or add one manually.</p></div>`}</div>`;
}
function tcard(x){ return `<div class="tcard" draggable="true" data-app="${x.id}"><div class="row" style="gap:10px;align-items:flex-start">${coLogo(x,32)}<div style="min-width:0"><b>${esc(x.title)}</b><small>${esc(x.company)}</small></div></div>${x.status==='interview'&&x.interview?`<div class="chip yellow" style="margin-top:9px">${ic('cal','style="width:12px;height:12px"')}${fmtDT(x.interview)}</div>`:''}<div class="tf"><span>${esc(x.salary||x.location||'')}</span><span>${fmtDate(x.date)}</span></div></div>`; }
function appModal(app){
  const isNew=!app; app=app||{id:uid(),jobId:'',title:'',company:'',location:'',color:'#2b86f0',salary:'',url:'',status:'applied',date:today(),notes:'',interview:''};
  modal({title:isNew?'Add application':esc(app.company),body:`<form id="appf" class="form-grid">
    <div class="field"><label>Job title</label><input class="input" name="title" required value="${esc(app.title)}"></div>
    <div class="field"><label>Company</label><input class="input" name="company" required value="${esc(app.company)}"></div>
    <div class="field"><label>Status</label><select class="select" name="status">${STAGES.map(s=>`<option value="${s.k}" ${app.status===s.k?'selected':''}>${s.n}</option>`).join('')}</select></div>
    <div class="field"><label>Date applied / saved</label><input class="input" type="date" name="date" value="${esc(app.date)}"></div>
    <div class="field"><label>Interview date & time</label><input class="input" type="datetime-local" name="interview" value="${esc(app.interview)}"></div>
    <div class="field"><label>Salary</label><input class="input" name="salary" value="${esc(app.salary)}" placeholder="$90k – $110k"></div>
    <div class="field"><label>Location</label><input class="input" name="location" value="${esc(app.location)}"></div>
    <div class="field"><label>Job link</label><input class="input" name="url" value="${esc(app.url)}" placeholder="https://"></div>
    <div class="field full"><label>Notes</label><textarea class="textarea" name="notes" placeholder="Contacts, next steps, follow-up dates…">${esc(app.notes)}</textarea></div></form>`,
    foot:`${isNew?'':`<button class="btn btn-danger" id="appDel" style="margin-right:auto">${ic('trash')}Delete</button>`}${!isNew&&app.jobId?`<a class="btn btn-ghost" href="#/interview?job=${esc(app.jobId)}">${ic('chat')}Prep</a>`:''}<button class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" id="appSave">Save</button>`,
    onMount(m){
      $('#appSave',m).onclick=()=>{ const f=$('#appf',m); if(!f.reportValidity()) return; const d=Object.fromEntries(new FormData(f));
        if(isNew){ if(S.apps.length>=plan().apps){ upgradeModal('Applying and tracking jobs is included with Pro and the Job Hunt Pass.'); return; } Object.assign(app,d); S.apps.push(app);} else Object.assign(app,d);
        save(); closeModal(); render(); toast(isNew?'Application added':'Saved'); };
      const dl=$('#appDel',m); dl&&(dl.onclick=()=>{ if(confirm('Delete this application?')){ S.apps=S.apps.filter(x=>x.id!==app.id); save(); closeModal(); render(); toast('Deleted','trash'); } });
    }});
}

/* ---------------- letters ---------------- */
function jobOptions(selected){
  const m=allJobs(); const tracked=S.apps.map(a=>a.jobId).filter(id=>m[id]);
  const rest=Object.keys(m).filter(id=>!tracked.includes(id));
  const opt=id=>`<option value="${esc(id)}" ${id===selected?'selected':''}>${esc(m[id].title)} — ${esc(m[id].company)}</option>`;
  return `${tracked.length?`<optgroup label="Your applications">${tracked.map(opt).join('')}</optgroup>`:''}<optgroup label="Jobs">${rest.map(opt).join('')}</optgroup><option value="__custom" ${selected==='__custom'?'selected':''}>Paste a job description…</option>`;
}
let letterDraft=null;
function vLetters(params){
  const jid=params.get('job')||letterDraft?.jobId||S.apps[0]?.jobId||SAMPLE_JOBS[0].id;
  return `<div class="grid" style="grid-template-columns:minmax(0,360px) minmax(0,1fr);align-items:start" id="lgrid">
  <div class="card stack">
    <div class="field"><label>Job</label><select class="select" id="lJob">${jobOptions(jid)}</select></div>
    <div id="lCustom" style="display:${jid==='__custom'?'block':'none'}" class="stack"><div class="form-grid"><div class="field"><label>Title</label><input class="input" id="cT"></div><div class="field"><label>Company</label><input class="input" id="cC"></div></div><div class="field"><label>Job description</label><textarea class="textarea" id="cD" rows="6"></textarea></div></div>
    <div class="field"><label>Tone</label><div class="tabs" id="lTone">${['professional','enthusiastic','concise'].map((t,i)=>`<button type="button" data-t="${t}" class="${(letterDraft?.tone||'professional')===t?'on':''}">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div></div>
    <button class="btn btn-hat btn-block" id="lGen">${ic('spark')}Generate cover letter</button>
    <p class="dim" style="font-size:12px">Uses your resume and the job's requirements. Always read and personalize before sending.</p>
  </div>
  <div class="stack">
    <div class="card"><div class="card-h"><h3>Your letter</h3><div class="row"><button class="btn btn-ghost btn-sm" id="lCopy">${ic('copy')}Copy</button><button class="btn btn-ghost btn-sm" id="lDl">${ic('download')}.txt</button><button class="btn btn-primary btn-sm" id="lSave">${ic('bookmark')}Save</button></div></div>
      <textarea class="ai-out textarea" id="lOut" style="min-height:420px;width:100%" placeholder="Pick a job and hit Generate — your tailored letter appears here.">${esc(letterDraft?.text||'')}</textarea>
      <div class="dim" style="font-size:12px;margin-top:8px" id="lSrc">${letterDraft?.source==='local'?'Written by the built-in writer':letterDraft?.source==='ai'?'Written by NXT AI':''}</div></div>
    <div class="card"><div class="card-h"><h3>Saved letters</h3><span class="muted">${S.letters.filter(l=>l.text).length}</span></div>
      ${S.letters.filter(l=>l.text).map(l=>`<div class="list-item"><div class="logo-sq" style="background:var(--surface3);color:var(--blue)">${ic('mail','style="width:18px;height:18px"')}</div><div class="li-main"><b>${esc(l.title)} — ${esc(l.company)}</b><small>${esc(l.tone)} · ${fmtDate(l.date)}</small></div><button class="btn btn-sm btn-ghost" data-open="${l.id}">Open</button><button class="icon-btn" data-ldel="${l.id}">${ic('trash','style="width:15px;height:15px"')}</button></div>`).join('')||'<div class="muted" style="font-size:13px">No saved letters yet.</div>'}</div>
  </div></div>`;
}

/* ---------------- interview ---------------- */
let prepCache={};
function vInterview(params){
  const jid=params.get('job')||S.apps.find(a=>a.status==='interview')?.jobId||SAMPLE_JOBS[0].id;
  const job=allJobs()[jid];
  const qs=prepCache[jid];
  return `<div class="card row wrap" style="gap:12px;margin-bottom:16px">
    <div class="field" style="flex:1;min-width:240px"><label>Prepare for</label><select class="select" id="iJob">${jobOptions(jid).replace(/<option value="__custom"[^>]*>.*?<\/option>/,'')}</select></div>
    <button class="btn btn-hat" id="iGen" style="align-self:flex-end">${ic('spark')}${qs?'Regenerate':'Generate questions'}</button></div>
  ${job?`<div class="grid" style="grid-template-columns:minmax(0,1fr) minmax(0,320px);align-items:start" id="igrid">
    <div id="iList">${qs?qList(jid,qs):`<div class="card empty"><img src="/assets/logo-256.png" alt=""><h4>Get ready for ${esc(job.company)}</h4><p>Generate the questions you're most likely to hear, with an answer plan built from your own resume.</p></div>`}</div>
    <div class="stack">
      <div class="card"><div class="row" style="gap:12px">${coLogo(job,44)}<div><b>${esc(job.title)}</b><div class="muted" style="font-size:12.5px">${esc(job.company)}</div></div></div>
        ${(()=>{const a=S.apps.find(x=>x.jobId===jid);return a&&a.interview?`<div class="chip yellow" style="margin-top:12px">${ic('cal','style="width:12px;height:12px"')}${fmtDT(a.interview)}</div>`:''})()}
        <div class="hr"></div><div class="dim" style="font-size:12px;margin-bottom:6px">Focus areas</div><div class="kw">${matchOf(job).have.slice(0,6).map(k=>`<span class="chip blue">${esc(k)}</span>`).join('')}${matchOf(job).missing.slice(0,3).map(k=>`<span class="chip yellow">${esc(k)}</span>`).join('')}</div></div>
      <div class="card"><h3 style="font-size:14px;margin-bottom:10px">The STAR method</h3>
        ${[['S','Situation','Set the scene in one sentence.'],['T','Task','What you were responsible for.'],['A','Action','What you did — most of your answer.'],['R','Result','Numbers, outcome, what you learned.']].map(([l,n,d])=>`<div class="check"><span class="ci" style="background:rgba(124,199,255,.12);color:var(--blue);font-weight:800;font-size:11px">${l}</span><span><b>${n}</b> <span class="muted">${d}</span></span></div>`).join('')}</div>
    </div></div>`:''}`;
}
function qList(jid,qs){
  const notes=S.prep[jid]||{};
  return qs.map((q,i)=>`<div class="q-item ${i===0?'open':''}" data-q="${i}"><div class="qh"><span class="qn">${i+1}</span><div style="flex:1"><div class="row between" style="align-items:flex-start"><b style="font-weight:600">${esc(q.q)}</b><span class="chip" style="margin-left:8px">${esc(q.cat)}</span></div></div></div>
    <div class="qa"><div style="margin-bottom:10px"><span class="dim" style="font-size:12px">How to answer</span><div>${esc(q.a)}</div></div><textarea class="textarea" data-note="${i}" rows="3" placeholder="Draft your answer…">${esc(notes[i]||'')}</textarea></div></div>`).join('');
}

/* ---------------- billing ---------------- */
function vBilling(params){
  const p=plan(), left=aiLeft();
  const feat=(a)=>a.map(x=>`<li>${ic('check')}${x}</li>`).join('');
  return `<div class="card row wrap between" style="margin-bottom:18px;gap:16px">
    <div class="row" style="gap:14px"><img src="/assets/logo-256.png" style="width:56px" alt=""><div><div class="dim" style="font-size:12px">Current plan</div><div style="font-size:20px;font-weight:750">${p.name}${S.plan!=='free'?` <span class="chip green" style="vertical-align:3px">Active</span>`:''}</div><div class="muted" style="font-size:13px">${S.plan==='free'?'You\'re previewing NXT Careers. Pick a plan to unlock everything.':S.plan==='pass'?'Access until '+fmtDate(S.planUntil):'Renews '+fmtDate(S.planUntil)}</div></div></div>
    ${S.plan==='free'?'':`<div style="min-width:220px"><div class="row between" style="font-size:12.5px"><span class="muted">AI writing</span><b>Unlimited</b></div><div class="bar" style="margin-top:8px"><i style="width:100%"></i></div></div>`}
  </div>
  <div class="grid g2" style="margin-top:22px;max-width:820px;margin-left:auto;margin-right:auto">
    <div class="card price-card hot"><span class="ribbon">MOST POPULAR</span><b>Pro</b><div class="amt">$9.99<small> / month</small></div><div class="muted">For an active job search</div>
      <ul>${feat(['Unlimited AI resume & bullet writing','Unlimited tailored cover letters','Interview prep for every job','All resume templates','Unlimited application tracking','Cancel anytime'])}</ul>
      <button class="btn btn-primary btn-block" data-buy="pro" ${S.plan==='pro'?'disabled':''}>${S.plan==='pro'?'Current plan':'Upgrade to Pro'}</button></div>
    <div class="card price-card"><b>Job Hunt Pass</b><div class="amt">$24.99<small> / 3 months</small></div><div class="muted">One payment, no renewal</div>
      <ul>${feat(['Everything in Pro for 90 days','Save 17% vs. monthly','No subscription to cancel','Great for a focused search sprint'])}</ul>
      <button class="btn btn-hat btn-block" data-buy="pass" ${S.plan==='pass'?'disabled':''}>${S.plan==='pass'?'Current plan':'Get the Pass'}</button></div>
  </div>
  <p class="dim" style="font-size:12px;margin-top:16px;text-align:center">Payments are processed securely by Stripe. Questions? <a href="mailto:${esc(CFG.supportEmail||'')}">${esc(CFG.supportEmail||'Contact support')}</a></p>
  <div class="card" style="margin-top:16px"><div class="card-h"><h3>Already paid on another device?</h3></div><div class="row wrap"><input class="input" id="sid" placeholder="Paste your Stripe checkout session ID (cs_…)" style="flex:1;min-width:220px"><button class="btn btn-ghost" id="verify">Restore purchase</button></div></div>`;
}
async function verifySession(sid){
  try{
    const r=await fetch('/api/verify?session_id='+encodeURIComponent(sid)); const j=await r.json();
    if(j.ok){ S.plan=j.plan; S.planUntil=j.until; save(); render(); toast(`${PLANS[j.plan].name} unlocked — thank you!`,'crown'); }
    else toast(j.error||'Could not verify that payment','x');
  }catch(e){ toast('Verification service unavailable','x'); }
}

/* ---------------- settings / more ---------------- */
function vSettings(){
  const u=S.user;
  return `<div class="grid g2" style="align-items:start">
  <div class="card"><div class="card-h"><h3>Profile</h3></div><form id="prof" class="form-grid">
    <div class="field"><label>Name</label><input class="input" name="name" value="${esc(u.name)}"></div>
    <div class="field"><label>Email</label><input class="input" name="email" value="${esc(u.email)}"></div>
    <div class="field"><label>Target role</label><input class="input" name="target" value="${esc(u.target)}"></div>
    <div class="field"><label>Preferred location</label><input class="input" name="location" value="${esc(u.location)}"></div>
    <div class="field"><label>Weekly application goal</label><input class="input" type="number" min="1" max="100" name="goal" value="${S.goal}"></div>
    <div class="field" style="justify-content:flex-end"><button class="btn btn-primary" type="submit">Save profile</button></div></form></div>
  <div class="stack">
    <div class="card"><div class="card-h"><h3>Connections</h3><button class="btn btn-ghost btn-sm" id="ping">Check</button></div>
      <div id="conn">${['Live job search (JSearch)','AI writing (Claude)','Payments (Stripe)'].map(n=>`<div class="list-item"><div class="li-main"><b>${n}</b></div><span class="chip">Not checked</span></div>`).join('')}</div></div>
    <div class="card"><div class="card-h"><h3>Your data</h3></div><p class="muted" style="font-size:13px;margin-bottom:12px">Everything is stored privately in this browser. Export a backup to move to another device.</p>
      <div class="row wrap"><button class="btn btn-ghost" id="exp">${ic('download')}Export backup</button><label class="btn btn-ghost">${ic('upload')}Import backup<input type="file" id="imp" accept="application/json" hidden></label><button class="btn btn-danger" id="reset">${ic('logout')}Sign out & erase</button></div></div>
  </div></div>`;
}
function vMore(){
  const it=(k,d)=>`<a class="list-item" href="#/${k}" style="color:inherit"><div class="logo-sq" style="background:var(--surface3);color:var(--blue)">${ic(ROUTES[k].i,'style="width:18px;height:18px"')}</div><div class="li-main"><b>${ROUTES[k].t}</b><small>${d}</small></div>${ic('right','style="width:18px;height:18px;color:var(--dim)"')}</a>`;
  return `<div class="card row" style="gap:14px;margin-bottom:14px"><div class="avatar" style="width:46px;height:46px;font-size:16px">${esc(initials(S.user.name))}</div><div><b style="font-size:16px">${esc(S.user.name)}</b><div class="muted">${esc(S.user.email||'')}</div></div><span class="chip ${S.plan==='free'?'':'yellow'}" style="margin-left:auto">${ic('crown','style="width:12px;height:12px"')}${plan().name}</span></div>
  <div class="card" style="padding:4px 16px">${it('letters','AI cover letters for any job')}${it('interview','Practice likely questions')}${it('billing','Plans, upgrades and receipts')}${it('settings','Profile, data and connections')}</div>
  <a href="/" class="btn btn-ghost btn-block" style="margin-top:14px">${ic('globe')}nxtcareers home</a>`;
}

/* ---------------- binders ---------------- */
const BIND = {
  dashboard(){ $('#goalEdit')?.addEventListener('click',()=>{ const v=prompt('Weekly application goal',S.goal); if(v&&+v>0){S.goal=+v;save();render();} }); },
  jobs(){
    if(!S.search.results) runSearch(); else if(!S.search.sel && innerWidth>900) refreshJobs();
    $('#jform').addEventListener('submit',e=>{ e.preventDefault(); const f=Object.fromEntries(new FormData(e.target)); S.search.q=f.q.trim(); S.search.loc=f.loc.trim(); S.search.sel=null; save(); runSearch(); });
    $$('.fchip').forEach(b=>b.onclick=()=>{ const k=b.dataset.f, f=S.search.filters; f.includes(k)?f.splice(f.indexOf(k),1):f.push(k); save(); if(k==='remote') runSearch(); else refreshJobs(); });
    $('#jl').addEventListener('click',e=>{
      const card=e.target.closest('[data-job]'); if(card){ S.search.sel=card.dataset.job; save(); refreshJobs(); if(innerWidth<=900) scrollTo(0,0); else $('#jdetail').scrollTop=0; return; }
      if(e.target.closest('#jback')){ S.search.sel=null; save(); refreshJobs(); return; }
      const j=allJobs()[S.search.sel]; if(!j) return;
      const sk=e.target.closest('[data-addskill]'); if(sk){ const k=sk.dataset.addskill; if(!S.resume.skills.some(s=>s.toLowerCase()===k.toLowerCase())) S.resume.skills.push(k); save(); refreshJobs(); toast(`Added “${k}” to your skills`); return; }
      const act=e.target.closest('[data-act]')?.dataset.act; if(!act) return;
      if(act==='apply'){ if(plan().locked){ upgradeModal('Applying and tracking jobs is included with Pro and the Job Hunt Pass.'); return; } window.open(applyUrl(j),'_blank','noopener'); if(trackJob(j,'applied')){ refreshJobs(); toast('Marked as applied in your tracker'); } }
      if(act==='track'){ if(trackJob(j,'saved')){ refreshJobs(); toast('Saved to tracker','bookmark'); } }
      if(act==='letter'){ S.jobs[j.id]=j; save(); letterDraft=null; location.hash='#/letters?job='+encodeURIComponent(j.id); }
      if(act==='prep'){ S.jobs[j.id]=j; save(); location.hash='#/interview?job='+encodeURIComponent(j.id); }
    });
  },
  resume(){
    const v=$('#view'), r=S.resume;
    v.addEventListener('input',e=>{ const p=e.target.dataset.b; if(p==null) return; set(r,p,e.target.value); save(); refreshPaper(); if(e.target.tagName==='TEXTAREA') autosize(e.target); });
    v.addEventListener('change',e=>{ if(e.target.dataset.b) rerenderResume(); });
    $$('.bullet-row textarea',v).forEach(autosize);
    v.addEventListener('click',async e=>{
      const h=e.target.closest('.card-h'); const secEl=h&&h.parentElement.dataset.sec;
      if(secEl && !e.target.closest('button')){ const o=S.ui.open; o.includes(secEl)?o.splice(o.indexOf(secEl),1):o.push(secEl); save(); h.parentElement.classList.toggle('open'); return; }
      const t=e.target.closest('button'); if(!t) return;
      if(t.dataset.del){ del(r,t.dataset.del); save(); rerenderResume(); return; }
      if(t.dataset.mv){ const [,i]=t.dataset.mv.split('.'); const k=+i; if(k>0){ const x=r.experience; [x[k-1],x[k]]=[x[k],x[k-1]]; save(); rerenderResume(); } return; }
      if(t.dataset.addb!=null){ r.experience[+t.dataset.addb].bullets.push(''); save(); rerenderResume(); return; }
      if(t.dataset.tpl){ if(!plan().templates.includes(t.dataset.tpl)){ upgradeModal('The '+t.dataset.tpl+' template is included with Pro.'); return; } r.template=t.dataset.tpl; save(); $$('.tpl-pick button').forEach(b=>b.classList.toggle('on',b===t)); refreshPaper(); return; }
      if(t.id==='addExp'){ r.experience.unshift({id:uid(),role:'',company:'',location:'',start:'',end:'Present',bullets:['']}); open('experience'); save(); rerenderResume(); return; }
      if(t.id==='addEdu'){ r.education.push({id:uid(),school:'',degree:'',start:'',end:'',detail:''}); open('education'); save(); rerenderResume(); return; }
      if(t.id==='addProj'){ r.projects.push({id:uid(),name:'',link:'',detail:''}); open('projects'); save(); rerenderResume(); return; }
      if(t.id==='pdf'){ if(plan().locked){ upgradeModal('PDF downloads are included with Pro and the Job Hunt Pass.'); return; } window.print(); return; }
      if(t.id==='atsTips'){ const a=AI.atsScore(r); modal({title:`ATS score: ${a.score}/100`,body:a.checks.map(c=>`<div class="check"><span class="ci ${c.ok?'ok':'no'}">${ic(c.ok?'check':'bolt')}</span><span>${c.k}${c.tip?` <span class="dim">(${c.tip})</span>`:''}</span></div>`).join('')+`<p class="muted" style="margin-top:12px;font-size:12.5px">Applicant tracking systems read plain, well-structured resumes best. Quantified achievements and job-specific keywords raise your ranking.</p>`,foot:`<button class="btn btn-primary" data-close>Got it</button>`}); return; }
      if(t.id==='aiSummary'){ if(!spendAI()) return; t.disabled=true; t.innerHTML=ic('spark')+'Writing…'; const out=await AI.summary(r); r.summary=out.text; save(); rerenderResume(); toast('Summary written — edit it to sound like you','spark'); return; }
      if(t.dataset.aib){ const [i,k]=t.dataset.aib.split('.').map(Number); const cur=r.experience[i].bullets[k]; if(!cur.trim()){ toast('Write a rough version first, then improve it','bolt'); return; } if(!spendAI()) return; t.disabled=true; t.style.opacity=.5; const out=await AI.bullet(cur,r); r.experience[i].bullets[k]=out.text; save(); rerenderResume(); toast(/\[/.test(out.text)?'Improved — replace the [brackets] with your real numbers':'Bullet improved','spark'); return; }
    });
    const si=$('#skillIn'); si.addEventListener('keydown',e=>{ if((e.key==='Enter'||e.key===',')&&si.value.trim()){ e.preventDefault(); si.value.split(',').map(x=>x.trim()).filter(Boolean).forEach(x=>r.skills.push(x)); save(); rerenderResume(); setTimeout(()=>$('#skillIn')?.focus()); } if(e.key==='Backspace'&&!si.value&&r.skills.length){ r.skills.pop(); save(); rerenderResume(); setTimeout(()=>$('#skillIn')?.focus()); } });
    function open(k){ if(!S.ui.open.includes(k)) S.ui.open.push(k); }
  },
  tracker(){
    $('#addApp').onclick=()=>appModal(null);
    $('#csv').onclick=()=>{ const rows=[['Title','Company','Status','Date','Interview','Salary','Location','Link','Notes'],...S.apps.map(a=>[a.title,a.company,a.status,a.date,a.interview,a.salary,a.location,a.url,a.notes])]; download('nxt-careers-applications.csv',rows.map(r=>r.map(c=>`"${String(c||'').replace(/"/g,'""')}"`).join(',')).join('\n'),'text/csv'); };
    $('#view').addEventListener('click',e=>{ const c=e.target.closest('[data-app]'); if(c) appModal(S.apps.find(a=>a.id===c.dataset.app)); });
    let dragId=null;
    $$('.tcard').forEach(c=>{ c.addEventListener('dragstart',()=>{dragId=c.dataset.app;c.classList.add('dragging')}); c.addEventListener('dragend',()=>c.classList.remove('dragging')); });
    $$('.col').forEach(col=>{ col.addEventListener('dragover',e=>{e.preventDefault();col.classList.add('drop')}); col.addEventListener('dragleave',()=>col.classList.remove('drop'));
      col.addEventListener('drop',e=>{ e.preventDefault(); col.classList.remove('drop'); const a=S.apps.find(x=>x.id===dragId); if(a&&a.status!==col.dataset.col){ a.status=col.dataset.col; if(a.status==='applied') a.date=today(); save(); render(); toast(`Moved to ${STAGES.find(s=>s.k===a.status).n}`); } }); });
  },
  letters(){
    let tone=letterDraft?.tone||'professional';
    const sel=$('#lJob'); sel.onchange=()=>{ $('#lCustom').style.display=sel.value==='__custom'?'block':'none'; };
    $$('#lTone button').forEach(b=>b.onclick=()=>{ tone=b.dataset.t; $$('#lTone button').forEach(x=>x.classList.toggle('on',x===b)); });
    const out=$('#lOut');
    $('#lGen').onclick=async()=>{
      let job; if(sel.value==='__custom'){ const t=$('#cT').value.trim(), c=$('#cC').value.trim(), d=$('#cD').value.trim(); if(!t||!c||!d){ toast('Add a title, company and description','bolt'); return; } job={id:'c_'+uid(),title:t,company:c,desc:d,resp:d.split(/\n|•|- /).map(x=>x.trim()).filter(x=>x.length>20).slice(0,4),qual:[],location:'',type:''}; S.jobs[job.id]=job; }
      else job=allJobs()[sel.value];
      if(!spendAI()) return;
      const b=$('#lGen'); b.disabled=true; b.innerHTML=ic('spark')+'Writing your letter…'; out.value=''; out.placeholder='Writing…';
      const r=await AI.cover(job,S.resume,tone);
      letterDraft={jobId:job.id,title:job.title,company:job.company,tone,text:r.text,source:r.source};
      out.value=r.text; b.disabled=false; b.innerHTML=ic('spark')+'Generate cover letter'; $('#lSrc').textContent=r.source==='ai'?'Written by NXT AI':'Written by the built-in writer'; save();
    };
    out.addEventListener('input',()=>{ if(letterDraft) letterDraft.text=out.value; });
    $('#lCopy').onclick=async()=>{ try{ await navigator.clipboard.writeText(out.value); toast('Copied','copy'); }catch(e){ out.select(); document.execCommand('copy'); toast('Copied','copy'); } };
    $('#lDl').onclick=()=>download(`Cover letter - ${letterDraft?.company||'NXT Careers'}.txt`,out.value,'text/plain');
    $('#lSave').onclick=()=>{ if(!out.value.trim()) return toast('Generate or write a letter first','bolt'); const d=letterDraft||{title:'Custom',company:'Letter',tone}; S.letters.unshift({id:uid(),jobId:d.jobId,title:d.title,company:d.company,tone:d.tone,date:today(),text:out.value}); save(); render(); toast('Letter saved','bookmark'); };
    $('#view').addEventListener('click',e=>{ const o=e.target.closest('[data-open]'); if(o){ const l=S.letters.find(x=>x.id===o.dataset.open); letterDraft={...l}; out.value=l.text; scrollTo(0,0); } const d=e.target.closest('[data-ldel]'); if(d){ S.letters=S.letters.filter(x=>x.id!==d.dataset.ldel); save(); render(); } });
  },
  interview(params){
    const sel=$('#iJob'); sel.onchange=()=>{ location.hash='#/interview?job='+encodeURIComponent(sel.value); };
    $('#iGen').onclick=async()=>{ const jid=sel.value, job=allJobs()[jid]; if(!spendAI()) return; const b=$('#iGen'); b.disabled=true; b.innerHTML=ic('spark')+'Preparing…'; $('#iList').innerHTML=`<div class="card">${'<div class="shimmer"></div>'.repeat(8)}</div>`; const r=await AI.interview(job,S.resume); prepCache[jid]=r.items; S.prepQ=S.prepQ||{}; S.prepQ[jid]=r.items; save(); render(); };
    $('#view').addEventListener('click',e=>{ const q=e.target.closest('.qh'); if(q) q.parentElement.classList.toggle('open'); });
    $('#view').addEventListener('input',e=>{ const n=e.target.dataset.note; if(n==null) return; const jid=sel.value; (S.prep[jid]=S.prep[jid]||{})[n]=e.target.value; save(); });
  },
  billing(params){
    const sid=params.get('session_id'); if(sid){ history.replaceState(null,'','#/billing'); verifySession(sid); }
    $$('[data-buy]').forEach(b=>b.onclick=()=>{
      const k=b.dataset.buy, link=k==='pro'?CFG.stripeProLink:CFG.stripePassLink;
      if(link){ const u=new URL(link); if(S.user.email) u.searchParams.set('prefilled_email',S.user.email); location.href=u.toString(); return; }
      if(CFG.demoMode){ S.plan=k; S.planUntil=addDays(k==='pass'?90:30); save(); render(); toast(`${PLANS[k].name} activated (demo mode — add Stripe links in config.js)`,'crown'); }
      else toast('Checkout is not configured yet','x');
    });
    $('#verify').onclick=()=>{ const v=$('#sid').value.trim(); if(v) verifySession(v); };
  },
  settings(){
    $('#prof').addEventListener('submit',e=>{ e.preventDefault(); const f=Object.fromEntries(new FormData(e.target)); S.goal=Math.max(1,+f.goal||10); delete f.goal; Object.assign(S.user,f); save(); render(); toast('Profile saved'); });
    $('#exp').onclick=()=>download(`nxt-careers-backup-${today()}.json`,JSON.stringify(S,null,2),'application/json');
    $('#imp').onchange=async e=>{ const f=e.target.files[0]; if(!f) return; try{ const d=JSON.parse(await f.text()); if(!d.resume||!d.user) throw 0; S=d; save(); render(); toast('Backup restored'); }catch(x){ toast('That file isn’t a NXT Careers backup','x'); } };
    $('#reset').onclick=()=>{ if(confirm('Erase all NXT Careers data from this browser? Export a backup first if you want to keep it.')){ localStorage.removeItem(KEY); S=null; location.hash=''; render(); } };
    const ping=async()=>{ const el=$('#conn'); let h={}; try{ h=await (await fetch('/api/health')).json(); }catch(e){}
      const row=(n,ok,live,off)=>`<div class="list-item"><div class="li-main"><b>${n}</b><small>${ok?live:off}</small></div><span class="chip ${ok?'green':'yellow'}">${ok?'Connected':'Fallback mode'}</span></div>`;
      el.innerHTML=row('Live job search (JSearch)',h.jobs,'Real listings from Indeed, LinkedIn, Glassdoor & more','Using sample listings — set RAPIDAPI_KEY')+row('AI writing (Claude)',h.ai,'Full AI writing enabled','Using the built-in writer — set ANTHROPIC_API_KEY')+row('Payments (Stripe)',h.stripe,'Purchases verify automatically','Set STRIPE_SECRET_KEY + Payment Links'); };
    $('#ping').onclick=ping; ping();
  }
};
function autosize(t){ t.style.height='auto'; t.style.height=Math.max(44,t.scrollHeight+2)+'px'; }
function download(name,text,type){ const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([text],{type})); a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),1000); }

/* restore cached interview questions */
if(S && S.prepQ) prepCache={...S.prepQ};
/* Stripe returns here as /app/?session_id=cs_... : verify the payment and unlock the plan */
(function(){
  const sid=new URLSearchParams(location.search).get('session_id');
  if(sid){ history.replaceState(null,'','/app/#/billing'); try{ localStorage.setItem('nxtc:pendingSid',sid); }catch(e){} }
})();
render();
function checkPendingPayment(){
  let sid=null; try{ sid=localStorage.getItem('nxtc:pendingSid'); }catch(e){}
  if(sid && S){ try{ localStorage.removeItem('nxtc:pendingSid'); }catch(e){} verifySession(sid); }
}
checkPendingPayment();
window.addEventListener('hashchange',checkPendingPayment);
})();

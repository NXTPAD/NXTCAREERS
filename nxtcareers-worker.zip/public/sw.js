// NXT Careers service worker: app shell works offline; API calls always go to the network.
const V = 'nxtc-v1';
const SHELL = ['/', '/index.html', '/app/', '/app/index.html', '/app/app.css', '/app/app.js', '/app/ai.js', '/app/data.js', '/config.js',
  '/assets/logo.png', '/assets/logo-256.png', '/assets/icon-192.png', '/assets/favicon-32.png', '/manifest.webmanifest'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return;
  // network first, fall back to cache (so updates ship immediately)
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(V).then(x => x.put(e.request, c)); return r; })
    .catch(() => caches.match(e.request).then(r => r || caches.match('/app/index.html'))));
});

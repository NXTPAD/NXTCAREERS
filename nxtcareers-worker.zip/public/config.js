/* NXT Careers — public configuration.
 * Paste your Stripe Payment Link URLs below. In each Payment Link's settings, set
 * "After payment → Redirect to" = https://nxtcareers.nxtcloud.xyz/app/?session_id={CHECKOUT_SESSION_ID}
 * The app then calls /api/verify (which uses your STRIPE_SECRET_KEY secret) to unlock the plan.
 *
 * demoMode: true lets you click "Upgrade" without paying (for testing). Set to false before launch.
 */
window.NXTC_CONFIG = {
  stripeProLink: "https://buy.stripe.com/test_4gM7sN643cUn0bva4Q1sQ01",       // e.g. https://buy.stripe.com/xxxx  ($9.99 / month subscription)
  stripePassLink: "https://buy.stripe.com/test_00wdRbgIHcUngatdh21sQ00",      // e.g. https://buy.stripe.com/yyyy  ($24.99 one-time, 3 months)
  demoMode: false,
  supportEmail: "nxtpadsupport@gmail.com"
};

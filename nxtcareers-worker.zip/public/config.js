/* NXT Careers — public configuration.
 * Paste your Stripe Payment Link URLs below. In each Payment Link's settings, set
 * "After payment → Redirect to" = https://YOURDOMAIN/app/#/billing?session_id={CHECKOUT_SESSION_ID}
 * The app then calls /api/verify (which uses your STRIPE_SECRET_KEY secret) to unlock the plan.
 *
 * demoMode: true lets you click "Upgrade" without paying (for testing). Set to false before launch.
 */
window.NXTC_CONFIG = {
  stripeProLink: "",       // e.g. https://buy.stripe.com/xxxx  ($9.99 / month subscription)
  stripePassLink: "",      // e.g. https://buy.stripe.com/yyyy  ($24.99 one-time, 3 months)
  demoMode: true,
  supportEmail: "nxtpadsupport@gmail.com"
};
